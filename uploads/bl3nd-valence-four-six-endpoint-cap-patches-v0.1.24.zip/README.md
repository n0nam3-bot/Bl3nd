# Bl3nd — Browser 3D Workspace

Bl3nd is a zero-build, mobile-first browser 3D modeling foundation. The app runs as static HTML/CSS/native JavaScript modules and uses Three.js from a pinned CDN import map.

## First deployment

1. Create a GitHub repository with a `main` branch.
2. Create `.github/workflows/unpack-update.yml` in the GitHub web editor using the exact bootstrap workflow supplied with this release.
3. In repository Settings, set Actions → General → Workflow permissions to **Read and write permissions**. Set Pages → Build and deployment → Source to **GitHub Actions**.
4. Upload `initial-release.zip` into the repository's `uploads/` folder. The action extracts it into the repository root, removes the uploaded ZIP and commits the files. A successful unpack run automatically triggers the GitHub Pages deployment workflow.

The application displays staged startup progress and keeps the exact startup error visible if initialization fails. The progress percentage represents completed initialization phases, not downloaded-byte progress.

The application does not require a build command. Open the GitHub Pages URL after the deployment workflow completes.

## Controls

- `Tab`: Object/Edit Mode
- `G`, `R`, `S`: start Move, Rotate or Scale; move the pointer to preview
- Free `G` follows the current camera view plane, so screen-right/screen-up move with the current view
- `X`, `Y`, `Z`: constrain to a global axis; `Shift + X/Y/Z`: constrain move/scale to the plane perpendicular to that axis
- Free `R` uses a camera-oriented virtual trackball; `R` + `X/Y/Z` rotates around a global axis
- Numeric keys, `Enter`, `Esc`: enter a value, apply, cancel
- Press `G/R/S` with the pointer over the viewport to begin there; otherwise the viewport center is used
- Edit Mode `1/2/3`: vertex/edge/face selection; selected topology is drawn directly over the mesh
- Edit Mode `Shift-click`: add/remove elements; `A`: select all; `Alt+A`: deselect; `Ctrl+I`: invert selection
- Edit Mode `B` / `C` / `L`: Box / Circle / Lasso selection; `Esc` returns to click selection. Hold `Shift` while dragging to add.
- Edge Select: select one or more seed edges, then `Alt+L` expands through opposite edges of connected quads; `Ctrl+Alt+L` follows opposite edges through closed all-quad vertex fans. At extraordinary poles, it pairs only a unique near-antiparallel edge direction (at least 155° apart with a clear best match); boundaries, mixed-face fans, non-manifold fans and ambiguous pairings are skipped. The Select menu exposes both operations.
- Edit Mode `X` / `Delete`: delete selected topology; `Shift+X`: dissolve selected topology; the viewport Select menu offers the same actions.
- Edit Mode `E` / `I`: Extrude / Inset
- Edge Select: select one supported interior edge, exactly two adjacent edges at one closed tri-valent corner, one simple connected path of three to eight consecutive edges (shared-face miters and triangulated cap patches for valence-four through valence-six terminal and internal junctions), two to four separate two-edge miter pairs (up to eight selected edges), or up to eight pairwise-disjoint interior edges, then use `Ctrl+B` or **Bevel** in the Edit Mesh panel. Drag horizontally to preview width; hold `Shift` for precision, use `←/→` for small width changes or type a factor from `0` to `0.95`. `Enter` applies the preview in one undoable operation; `Esc` or right-click cancels. On mobile, drag or use the on-screen numeric pad. Every chain vertex recovers its ordered opposite fan arc. Valence-four caps use one triangle; valence-five/six caps use a center-fanned triangle patch. Cap winding must oppose every existing boundary edge. Four- through seven-edge paths are regression-tested across every simple path on a cube, and mixed tri-/valence-four/five/six fixtures cover multi-junction chains. Branches, cycles, mixed connected/disconnected selections and overlapping independent neighborhoods are rejected. Convex planar boundary-free source neighborhoods are required; both endpoints and internal junctions may have closed valence-three through valence-six fans. Valence-five/six patches use reduced profile amplitude to avoid foldovers. Fans above valence six, boundaries, non-manifold topology and ambiguous cap boundaries are rejected without mutation.
- Edge Select: select exactly one seed edge, then `Ctrl+R` or **Loop Cut** in the Edit Mesh panel. Drag horizontally to slide the live cut preview; hold `Shift` for precision, use `←/→` for 1% steps (Shift for 0.1%), or type an offset from `0` to `1`. `Enter` applies and `Esc` cancels. Use the mouse wheel or `+` / `-` to adjust 1–8 evenly spaced cuts; all cuts slide together. On mobile, drag in the viewport, type the slide value, or use the on-screen cut-count buttons.
- `Shift + A`: add menu; `Z`: shading menu
- Numpad `1/3/7`: front/right/top views; scroll: zoom
- Desktop: left-drag or middle-drag to orbit; right-drag or Shift+left-drag to pan; scroll to zoom; a stationary click selects
- Mobile: one-finger orbit, two-finger pan/zoom, long-press to place cursor and bottom quick actions; choose Box / Circle / Lasso from the viewport Select menu for drag selection, then return to Click Select to orbit with one finger.
- Edit Mesh panel: Delete and Dissolve use the active vertex/edge/face selection; Validate Mesh reports topology problems, and Repair Safe Issues handles only conservative repairs. Loop Cut is available from the panel or Ctrl+R while one seed edge is selected. Bevel is available from the panel or Ctrl+B for one supported edge, exactly two adjacent edges at one tri-valent corner, one simple connected path of three to eight consecutive edges with shared miters and two closed end caps (valence-four through valence-six terminal and internal junctions receive triangulated cap patches), two to four disjoint two-edge miter pairs, or up to eight pairwise-disjoint single-edge neighborhoods; all previews are transactional and commit one undo step.
- Concave planar polygons are ear-clipped for rendering and selection. Dissolve can merge a simple concave planar patch; non-planar, self-intersecting and non-manifold patches remain unchanged.

Run all topology/operator regression tests with Node: `node --experimental-default-type=module --test tests/*.test.js`.

See [`HANDOFF.md`](./HANDOFF.md) for architecture, exact implementation status, limitations and roadmap. This is an initial engineering foundation, not yet a feature-for-feature Blender clone.


### Safe topology repair

In Edit Mode, **Repair Safe Issues** removes malformed faces and duplicate faces, reorients consistently orientable manifold face components, and compacts unused vertices. It deliberately does not guess how to repair non-manifold edges, non-planar faces, self-intersections, or contradictory/non-orientable components; those remain in the validation report for manual correction. Use **Validate Mesh** before and after repair to inspect what changed.

### Bevel

Select one edge in Edge Select mode on a closed manifold mesh. The single-edge template is limited to an edge whose two endpoints each have exactly three incident faces, with all four affected faces simple, planar and convex. It replaces the selected edge with a bevel strip and selects its new perimeter.

Connected bevel supports exactly two adjacent edges sharing one closed, tri-valent corner, or one simple path of three to eight consecutive selected edges. The two-edge case intersects offset lines in the common face, creates one shared miter edge and adds two joined bevel strips. Longer chains create one shared-face miter at each internal vertex and close both terminal ends with fan-aware cap patches when needed. Both endpoints and internal junctions may have closed valence-three, -four, -five or -six fans. The ordered opposite fan arc is trimmed at every non-selected radial edge. Valence-four junctions receive one triangular patch; valence-five/six junctions receive center-fanned triangle patches, with one uniquely oriented outer boundary and individually planar triangles. The fan boundary must be simple and convex in its stable projection. Mixed-valence chain regressions cover repeated cap patches, reversed path order, rotated geometry, all 1–8 segment counts and zero-boundary topology. If any chain vertex has valence five or six, profile amplitude is conservatively scaled to 25% to avoid foldovers; the modal reports this limit only when using multiple segments. The exhaustive cube regressions cover all 360 simple tri-valent paths of four through seven edges, and a segmented eight-edge path passes on a closed pentagonal prism. Cycles, branches, mixed connected/disconnected selections, valence above six at either endpoint or internal junction, overlapping cap regions and ambiguous miter intersections are rejected before source mutation. You can also select two to four separate two-edge pairs and process their miter junctions in one transaction when their affected face neighborhoods are disjoint. Alternatively, select up to eight pairwise-disjoint single edges to bevel independent neighborhoods together. The amount is a normalized factor of the safe maximum (45% of the shortest neighboring edge), not a world-unit distance.

Bevel supports **1–8 segments** across each accepted single-edge, connected pair/chain, and disconnected-edge combination. One segment keeps the original strip topology. With multiple segments, the strip is divided into intermediate rows and triangulated per segment; shared miter rows reuse the same vertices so adjacent strips stay connected. The **Profile** control shapes the intermediate cross-section points inside the terminal cap planes: `0` is concave, `0.50` is the default rounded profile, and `1` is convex. Profile shaping is active with two or more segments; the shared miter seam itself stays straight. Candidate topology and triangulation are validated before any source replacement.

Press **Ctrl+B** or choose **Bevel** in the Edit Mesh panel. Drag horizontally, hold `Shift` for width precision, use arrow keys to nudge width, or type an amount from `0` to `0.95`. Press `+`/`-` to change segments and `[`/`]` to change profile; Shift with the bracket keys makes fine `0.01` profile adjustments. On mobile, use the on-screen segment and profile +/- rows. `Enter` commits one undoable operation; `Esc` or right-click restores the original mesh. Every preview is rebuilt from the original source, and the complete candidate is topology-validated before commit. Boundary edges, non-manifold or inconsistently wound meshes, existing topology warnings, non-planar/concave faces, fans above valence six, ambiguous miter intersections and excessive miters are rejected without mutation. Chains longer than eight selected edges, branches, cycles, mixed connected/disconnected selections, internal junctions above valence six and open-boundary bevels remain unsupported.

### Loop Cut

Select exactly one edge in Edge Select mode, then press **Ctrl+R** or use **Loop Cut** in the Edit Mesh panel. The operation follows the quad-opposite edge loop and previews 1–8 evenly spaced cuts, sharing an interpolated vertex per cut and crossed edge. Drag horizontally to slide the cut group; hold `Shift` for fine movement, use arrow keys for small nudges, or type a group offset between `0` and `1`. Use the mouse wheel or `+` / `-` to change the number of cuts. `Enter` commits one undoable operation; `Esc` or right-click restores the original mesh. Mobile users can drag, enter an offset, or use the on-screen cut-count controls. Each crossed quad is split into `cuts + 1` quads and all new cut edges remain selected. It currently accepts only consistently wound, convex, planar quad strips. Non-manifold, non-quad, concave, non-planar, or inconsistently wound paths are rejected before mutation. Loop Cut itself still stops at extraordinary poles; the pole-aware behavior currently applies only to Edge Ring selection. N-gons, multiple distinct seed loops and Blender-equivalent edge sliding remain unsupported.
