function keyFor(a, b) { return a < b ? `${a}:${b}` : `${b}:${a}`; }

function cross2(a, b, c) {
  return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
}

function newellNormal(positions, face) {
  const normal = [0, 0, 0];
  for (let i = 0; i < face.length; i++) {
    const a = positions[face[i]], b = positions[face[(i + 1) % face.length]];
    if (!a || !b) return null;
    normal[0] += (a[1] - b[1]) * (a[2] + b[2]);
    normal[1] += (a[2] - b[2]) * (a[0] + b[0]);
    normal[2] += (a[0] - b[0]) * (a[1] + b[1]);
  }
  const length = Math.hypot(...normal);
  return length > 1e-12 ? normal.map(value => value / length) : null;
}

function projectedPolygon(positions, face) {
  if (!Array.isArray(face) || face.length < 3 || new Set(face).size !== face.length ||
      face.some(id => !Number.isInteger(id) || !positions[id] || positions[id].length < 3 || !positions[id].every(Number.isFinite))) return null;
  let normal = newellNormal(positions, face);
  // A self-crossing polygon can have zero signed Newell area despite containing
  // a usable plane. Recover a projection normal so validation can identify it.
  if (!normal) {
    const origin = positions[face[0]];
    for (let i = 1; i < face.length - 1 && !normal; i++) {
      const b = positions[face[i]], c = positions[face[i + 1]];
      const u = b.map((value, axis) => value - origin[axis]);
      const v = c.map((value, axis) => value - origin[axis]);
      const cross = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
      const length = Math.hypot(...cross);
      if (length > 1e-12) normal = cross.map(value => value / length);
    }
  }
  if (!normal) return null;
  const dropAxis = normal.reduce((best, value, axis) => Math.abs(value) > Math.abs(normal[best]) ? axis : best, 0);
  const points = face.map(id => {
    const p = positions[id];
    return dropAxis === 0 ? [p[1], p[2]] : dropAxis === 1 ? [p[0], p[2]] : [p[0], p[1]];
  });
  const min = [0, 1].map(axis => Math.min(...points.map(point => point[axis])));
  const max = [0, 1].map(axis => Math.max(...points.map(point => point[axis])));
  const scale = Math.max(1, max[0] - min[0], max[1] - min[1]);
  const origin = positions[face[0]];
  const deviation = Math.max(...face.map(id => Math.abs(normal.reduce((sum, value, axis) => sum + value * (positions[id][axis] - origin[axis]), 0))));
  return { normal, points, scale, deviation };
}

function pointOnSegment2D(p, a, b, epsilon) {
  if (Math.abs(cross2(a, b, p)) > epsilon) return false;
  const dot = (p[0] - a[0]) * (p[0] - b[0]) + (p[1] - a[1]) * (p[1] - b[1]);
  return dot <= epsilon;
}

function segmentsIntersect2D(a, b, c, d, epsilon) {
  const abC = cross2(a, b, c), abD = cross2(a, b, d);
  const cdA = cross2(c, d, a), cdB = cross2(c, d, b);
  if (((abC > epsilon && abD < -epsilon) || (abC < -epsilon && abD > epsilon)) &&
      ((cdA > epsilon && cdB < -epsilon) || (cdA < -epsilon && cdB > epsilon))) return true;
  return (Math.abs(abC) <= epsilon && pointOnSegment2D(c, a, b, epsilon)) ||
    (Math.abs(abD) <= epsilon && pointOnSegment2D(d, a, b, epsilon)) ||
    (Math.abs(cdA) <= epsilon && pointOnSegment2D(a, c, d, epsilon)) ||
    (Math.abs(cdB) <= epsilon && pointOnSegment2D(b, c, d, epsilon));
}

function polygonSelfIntersects(points, epsilon) {
  const count = points.length;
  for (let i = 0; i < count; i++) {
    const a = points[i], b = points[(i + 1) % count];
    for (let j = i + 1; j < count; j++) {
      if (j === i || j === (i + 1) % count || (j + 1) % count === i) continue;
      const c = points[j], d = points[(j + 1) % count];
      if (segmentsIntersect2D(a, b, c, d, epsilon)) return true;
    }
  }
  return false;
}

function signedArea2D(points) {
  let area = 0;
  for (let i = 0; i < points.length; i++) {
    const a = points[i], b = points[(i + 1) % points.length];
    area += a[0] * b[1] - b[0] * a[1];
  }
  return area * 0.5;
}

function pointInTriangle2D(point, a, b, c, winding, epsilon) {
  const ab = cross2(a, b, point) * winding;
  const bc = cross2(b, c, point) * winding;
  const ca = cross2(c, a, point) * winding;
  return ab >= -epsilon && bc >= -epsilon && ca >= -epsilon;
}

/** Ear-clips a simple polygon while preserving the source winding and vertex IDs. */
function triangulatePolygon(positions, face) {
  const projection = projectedPolygon(positions, face);
  if (!projection) return null;
  const { points, scale } = projection;
  const epsilon = scale * scale * 1e-10;
  if (polygonSelfIntersects(points, epsilon)) return null;
  const area = signedArea2D(points);
  if (Math.abs(area) <= epsilon) return null;
  const winding = Math.sign(area);
  let ring = face.map((id, index) => ({ id, point: points[index] }));

  // Remove redundant collinear points from the triangulation ring; they remain
  // in the HEM boundary and therefore remain visible as editable edges.
  let changed = true;
  while (changed && ring.length > 3) {
    changed = false;
    for (let i = 0; i < ring.length; i++) {
      const prev = ring[(i - 1 + ring.length) % ring.length].point;
      const current = ring[i].point;
      const next = ring[(i + 1) % ring.length].point;
      if (Math.abs(cross2(prev, current, next)) <= epsilon &&
          (current[0] - prev[0]) * (current[0] - next[0]) +
          (current[1] - prev[1]) * (current[1] - next[1]) <= epsilon) {
        ring.splice(i, 1);
        changed = true;
        break;
      }
    }
  }
  if (ring.length < 3) return null;

  const triangles = [];
  let guard = ring.length * ring.length;
  while (ring.length > 3 && guard-- > 0) {
    let earFound = false;
    for (let i = 0; i < ring.length; i++) {
      const prev = ring[(i - 1 + ring.length) % ring.length];
      const current = ring[i];
      const next = ring[(i + 1) % ring.length];
      if (cross2(prev.point, current.point, next.point) * winding <= epsilon) continue;
      let containsVertex = false;
      for (let j = 0; j < ring.length; j++) {
        if (j === i || j === (i - 1 + ring.length) % ring.length || j === (i + 1) % ring.length) continue;
        if (pointInTriangle2D(ring[j].point, prev.point, current.point, next.point, winding, epsilon)) {
          containsVertex = true;
          break;
        }
      }
      if (containsVertex) continue;
      triangles.push([prev.id, current.id, next.id]);
      ring.splice(i, 1);
      earFound = true;
      break;
    }
    if (!earFound) return null;
  }
  if (ring.length !== 3 || Math.abs(cross2(ring[0].point, ring[1].point, ring[2].point)) <= epsilon) return null;
  triangles.push([ring[0].id, ring[1].id, ring[2].id]);
  return triangles;
}


function mergeCoplanarTriangles(vertices, triangles) {
  if (triangles.length < 2) return triangles.map(face => [...face]);
  const planes = triangles.map(face => {
    const a = vertices[face[0]], b = vertices[face[1]], c = vertices[face[2]];
    const u = b.map((value, i) => value - a[i]), v = c.map((value, i) => value - a[i]);
    const normal = [u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0]];
    const length = Math.hypot(...normal);
    if (length < 1e-12) return null;
    const n = normal.map(value => value / length);
    return { normal: n, distance: n.reduce((sum, value, i) => sum + value * a[i], 0) };
  });
  const parent = triangles.map((_, index) => index);
  const find = id => { while (parent[id] !== id) { parent[id] = parent[parent[id]]; id = parent[id]; } return id; };
  const join = (a, b) => { const ra = find(a), rb = find(b); if (ra !== rb) parent[rb] = ra; };
  const edgeFaces = new Map();
  triangles.forEach((face, faceId) => {
    for (let i = 0; i < 3; i++) {
      const key = keyFor(face[i], face[(i + 1) % 3]);
      if (!edgeFaces.has(key)) edgeFaces.set(key, []);
      edgeFaces.get(key).push(faceId);
    }
  });
  const nonManifoldFaces = new Set();
  for (const incident of edgeFaces.values()) {
    if (incident.length > 2) {
      incident.forEach(id => nonManifoldFaces.add(id));
      continue;
    }
    if (incident.length !== 2) continue;
    const [a, b] = incident, pa = planes[a], pb = planes[b];
    if (!pa || !pb) continue;
    const alignment = pa.normal.reduce((sum, value, axis) => sum + value * pb.normal[axis], 0);
    if (alignment > 0.999999 && Math.abs(pa.distance - pb.distance) < 1e-5) join(a, b);
  }

  const components = new Map();
  triangles.forEach((face, id) => {
    const root = find(id);
    if (!components.has(root)) components.set(root, []);
    components.get(root).push(id);
  });
  const merged = [];
  for (const ids of components.values()) {
    if (ids.length === 1 || ids.some(id => nonManifoldFaces.has(id))) {
      for (const id of ids) merged.push([...triangles[id]]);
      continue;
    }
    const counts = new Map(), directed = new Map();
    for (const id of ids) {
      const face = triangles[id];
      for (let i = 0; i < 3; i++) {
        const a = face[i], b = face[(i + 1) % 3], key = keyFor(a, b);
        counts.set(key, (counts.get(key) || 0) + 1);
        directed.set(key, [a, b]);
      }
    }
    const boundary = [...counts].filter(([, count]) => count === 1).map(([key]) => directed.get(key));
    const outgoing = new Map();
    let valid = boundary.length >= 3;
    for (const [a, b] of boundary) {
      if (outgoing.has(a)) valid = false;
      outgoing.set(a, b);
    }
    let polygon = [];
    if (valid) {
      const start = boundary[0][0]; let current = start;
      for (let i = 0; i < boundary.length; i++) {
        if (!outgoing.has(current)) { valid = false; break; }
        polygon.push(current); current = outgoing.get(current);
        if (current === start) break;
      }
      if (current !== start || polygon.length !== boundary.length || new Set(polygon).size !== polygon.length) valid = false;
    }
    // Only replace a triangle cluster with one convex, single-boundary polygon.
    if (valid) {
      const normal = planes[ids[0]]?.normal || [0, 0, 1];
      for (let i = 0; i < polygon.length; i++) {
        const a = vertices[polygon[i]], b = vertices[polygon[(i + 1) % polygon.length]], c = vertices[polygon[(i + 2) % polygon.length]];
        const ab = b.map((value, axis) => value - a[axis]), bc = c.map((value, axis) => value - b[axis]);
        const cross = [ab[1]*bc[2]-ab[2]*bc[1], ab[2]*bc[0]-ab[0]*bc[2], ab[0]*bc[1]-ab[1]*bc[0]];
        if (cross.reduce((sum, value, axis) => sum + value * normal[axis], 0) < -1e-7) { valid = false; break; }
      }
    }
    if (valid) merged.push(polygon);
    else for (const id of ids) merged.push([...triangles[id]]);
  }
  return merged;
}

export class Vertex {
  constructor(id, position) { this.id = id; this.position = position; this.halfEdge = null; }
}
export class Edge {
  constructor(id, a, b) { this.id = id; this.vertices = [a, b]; this.halfEdges = []; }
}
export class HalfEdge {
  constructor(id, origin, face, edge) {
    this.id = id; this.origin = origin; this.face = face; this.edge = edge;
    this.next = null; this.prev = null; this.twin = null;
  }
}
export class Face {
  constructor(id) { this.id = id; this.halfEdge = null; this.vertices = []; }
}

/** Editable polygon topology. The Three.js geometry is a render cache only. */
export class HalfEdgeMesh {
  constructor(vertices = [], faces = []) {
    this.positions = vertices.map(v => [...v]);
    this.faces = faces.map(f => [...f]);
    this.vertices = []; this.edges = []; this.halfEdges = []; this.faceRecords = [];
    this.vertexSelection = new Set(); this.edgeSelection = new Set(); this.faceSelection = new Set();
    this.selectionMode = 'face';
    this.lastRingTraversal = { regularVertices: 0, extraordinaryVertices: 0, ambiguousPoles: 0, stoppedFans: 0 };
    this.rebuild();
  }

  static fromBufferGeometry(geometry) {
    const attr = geometry.getAttribute('position');
    if (!attr) return new HalfEdgeMesh();
    const source = geometry.index ? Array.from(geometry.index.array) : Array.from({ length: attr.count }, (_, i) => i);
    const vertices = [], map = new Map(), faces = [];
    const quantize = n => Math.round(n * 100000) / 100000;
    const remap = sourceIndex => {
      const x = quantize(attr.getX(sourceIndex)), y = quantize(attr.getY(sourceIndex)), z = quantize(attr.getZ(sourceIndex));
      const key = `${x},${y},${z}`;
      if (!map.has(key)) { map.set(key, vertices.length); vertices.push([x, y, z]); }
      return map.get(key);
    };
    for (let i = 0; i + 2 < source.length; i += 3) {
      const tri = [remap(source[i]), remap(source[i + 1]), remap(source[i + 2])];
      if (new Set(tri).size === 3) faces.push(tri);
    }
    return new HalfEdgeMesh(vertices, mergeCoplanarTriangles(vertices, faces));
  }

  rebuild() {
    this.vertices = this.positions.map((position, id) => new Vertex(id, position));
    this.edges = []; this.halfEdges = []; this.faceRecords = [];
    const edgeMap = new Map();
    this.faces.forEach((indices, faceId) => {
      const face = new Face(faceId); face.vertices = [...indices];
      const cycle = [];
      for (let i = 0; i < indices.length; i++) {
        const a = indices[i], b = indices[(i + 1) % indices.length];
        if (!this.vertices[a] || !this.vertices[b] || a === b) continue;
        const key = keyFor(a, b);
        let edge = edgeMap.get(key);
        if (!edge) { edge = new Edge(this.edges.length, Math.min(a, b), Math.max(a, b)); edgeMap.set(key, edge); this.edges.push(edge); }
        const he = new HalfEdge(this.halfEdges.length, a, face, edge);
        this.halfEdges.push(he); edge.halfEdges.push(he); cycle.push(he);
        if (!this.vertices[a].halfEdge) this.vertices[a].halfEdge = he;
      }
      if (cycle.length) {
        cycle.forEach((he, i) => { he.next = cycle[(i + 1) % cycle.length]; he.prev = cycle[(i - 1 + cycle.length) % cycle.length]; });
        face.halfEdge = cycle[0];
      }
      this.faceRecords.push(face);
    });
    for (const edge of this.edges) {
      if (edge.halfEdges.length === 2) {
        const [a, b] = edge.halfEdges;
        if (a.origin === b.next.origin) { a.twin = b; b.twin = a; }
      }
    }
    this.vertexSelection = new Set([...this.vertexSelection].filter(id => id < this.vertices.length));
    this.edgeSelection = new Set([...this.edgeSelection].filter(id => id < this.edges.length));
    this.faceSelection = new Set([...this.faceSelection].filter(id => id < this.faceRecords.length));
  }

  clone() { return new HalfEdgeMesh(this.positions, this.faces); }
  setSelectionMode(mode) {
    if (!['vertex', 'edge', 'face'].includes(mode) || mode === this.selectionMode) return;
    const vertices = new Set(), edges = new Set(), faces = new Set();
    const edgeIds = new Map(this.edges.map(edge => [keyFor(...edge.vertices), edge.id]));
    if (mode === 'vertex') {
      if (this.faceSelection.size) for (const faceId of this.faceSelection) for (const id of this.faces[faceId] || []) vertices.add(id);
      else if (this.edgeSelection.size) for (const edgeId of this.edgeSelection) for (const id of this.edges[edgeId]?.vertices || []) vertices.add(id);
      else for (const id of this.vertexSelection) vertices.add(id);
    } else if (mode === 'edge') {
      if (this.faceSelection.size) {
        for (const faceId of this.faceSelection) {
          const face = this.faces[faceId] || [];
          for (let i = 0; i < face.length; i++) { const id = edgeIds.get(keyFor(face[i], face[(i + 1) % face.length])); if (id !== undefined) edges.add(id); }
        }
      } else if (this.vertexSelection.size) {
        for (const edge of this.edges) if (this.vertexSelection.has(edge.vertices[0]) && this.vertexSelection.has(edge.vertices[1])) edges.add(edge.id);
      } else for (const id of this.edgeSelection) edges.add(id);
    } else {
      if (this.vertexSelection.size) {
        for (let faceId = 0; faceId < this.faces.length; faceId++) if (this.faces[faceId].every(id => this.vertexSelection.has(id))) faces.add(faceId);
      } else if (this.edgeSelection.size) {
        for (let faceId = 0; faceId < this.faces.length; faceId++) {
          const face = this.faces[faceId] || [];
          if (face.length && face.every((id, i) => { const edgeId = edgeIds.get(keyFor(id, face[(i + 1) % face.length])); return edgeId !== undefined && this.edgeSelection.has(edgeId); })) faces.add(faceId);
        }
      } else for (const id of this.faceSelection) faces.add(id);
    }
    this.clearSelection();
    this.vertexSelection = vertices; this.edgeSelection = edges; this.faceSelection = faces;
    this.selectionMode = mode;
  }

  clearSelection() { this.vertexSelection.clear(); this.edgeSelection.clear(); this.faceSelection.clear(); }

  selectVertex(id, additive = false) {
    if (!this.vertices[id]) return;
    if (!additive) this.clearSelection();
    if (additive && this.vertexSelection.has(id)) this.vertexSelection.delete(id);
    else this.vertexSelection.add(id);
  }

  selectEdge(id, additive = false) {
    if (!this.edges[id]) return;
    if (!additive) this.clearSelection();
    if (additive && this.edgeSelection.has(id)) this.edgeSelection.delete(id);
    else this.edgeSelection.add(id);
  }

  selectFace(id, additive = false) {
    if (!this.faceRecords[id]) return;
    if (!additive) this.clearSelection();
    if (additive && this.faceSelection.has(id)) { this.faceSelection.delete(id); return; }
    if (this.selectionMode === 'face') { this.faceSelection.add(id); return; }
    const face = this.faces[id], edgeIds = new Map(this.edges.map(edge => [keyFor(...edge.vertices), edge.id]));
    if (this.selectionMode === 'vertex') for (const vertexId of face) this.vertexSelection.add(vertexId);
    if (this.selectionMode === 'edge') for (let i = 0; i < face.length; i++) {
      const edgeId = edgeIds.get(keyFor(face[i], face[(i + 1) % face.length]));
      if (edgeId !== undefined) this.edgeSelection.add(edgeId);
    }
  }

  triangulateFace(faceId) {
    const face = this.faces[faceId];
    return face ? triangulatePolygon(this.positions, face) || [] : [];
  }

  triangleFaceMap() {
    const faceIds = [];
    this.faces.forEach((_, faceId) => {
      for (const _triangle of this.triangulateFace(faceId)) faceIds.push(faceId);
    });
    return faceIds;
  }

  toBufferGeometry() {
    const positions = this.positions.flat();
    const indices = [];
    for (let faceId = 0; faceId < this.faces.length; faceId++) {
      for (const triangle of this.triangulateFace(faceId)) indices.push(...triangle);
    }
    return { positions: new Float32Array(positions), indices: new Uint32Array(indices) };
  }

  faceNormal(faceId) {
    const face = this.faces[faceId];
    if (!face || face.length < 3) return [0, 0, 1];
    const a = this.positions[face[0]], b = this.positions[face[1]], c = this.positions[face[2]];
    const u = [b[0]-a[0], b[1]-a[1], b[2]-a[2]], v = [c[0]-a[0], c[1]-a[1], c[2]-a[2]];
    const n = [u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0]];
    const length = Math.hypot(...n) || 1;
    return n.map(x => x / length);
  }

  extrudeSelected(distance = 1) {
    const selected = [...this.faceSelection];
    if (!selected.length) return false;
    const selectedSet = new Set(selected), boundary = new Map(), normal = [0, 0, 0], used = new Set();
    for (const faceId of selected) {
      const face = this.faces[faceId]; const n = this.faceNormal(faceId);
      n.forEach((v, i) => normal[i] += v);
      for (const v of face) used.add(v);
      for (let i = 0; i < face.length; i++) {
        const a = face[i], b = face[(i + 1) % face.length], key = keyFor(a, b);
        const item = boundary.get(key) || { count: 0, a, b };
        item.count++; boundary.set(key, item);
      }
    }
    const nLen = Math.hypot(...normal) || 1; normal.forEach((v, i) => normal[i] = v / nLen);
    const remap = new Map();
    for (const oldId of used) {
      remap.set(oldId, this.positions.length);
      this.positions.push(this.positions[oldId].map((v, axis) => v + normal[axis] * distance));
    }
    const oldFaces = this.faces.map((face, id) => selectedSet.has(id) ? face.map(v => remap.get(v)) : face);
    for (const edge of boundary.values()) if (edge.count === 1) oldFaces.push([edge.a, edge.b, remap.get(edge.b), remap.get(edge.a)]);
    this.faces = oldFaces;
    this.clearSelection();
    for (let id = 0; id < selected.length; id++) this.faceSelection.add(selected[id]);
    this.rebuild();
    this.faceSelection = new Set(selected.map(id => id));
    return true;
  }

  insetSelected(amount = 0.12) {
    const selected = [...this.faceSelection];
    if (!selected.length) return false;
    const selectedSet = new Set(selected), replacement = [], innerFaceIds = [];
    const kept = this.faces.filter((_, id) => !selectedSet.has(id));
    for (const faceId of selected) {
      const face = this.faces[faceId];
      const center = [0, 0, 0];
      face.forEach(v => this.positions[v].forEach((p, i) => center[i] += p / face.length));
      const ring = face.map(v => {
        const p = this.positions[v]; const id = this.positions.length;
        this.positions.push(p.map((n, i) => n * (1 - amount) + center[i] * amount)); return id;
      });
      for (let i = 0; i < face.length; i++) replacement.push([face[i], face[(i + 1) % face.length], ring[(i + 1) % face.length], ring[i]]);
      innerFaceIds.push(kept.length + replacement.length);
      replacement.push(ring);
    }
    this.faces = [...kept, ...replacement];
    this.clearSelection();
    this.rebuild();
    this.faceSelection = new Set(innerFaceIds);
    return true;
  }

  deleteSelectedElements() {
    const removedFaces = new Set();
    if (this.selectionMode === 'face') {
      for (const id of this.faceSelection) if (this.faces[id]) removedFaces.add(id);
    } else if (this.selectionMode === 'edge') {
      for (const edgeId of this.edgeSelection) {
        for (const halfEdge of this.edges[edgeId]?.halfEdges || []) {
          if (Number.isInteger(halfEdge.face?.id)) removedFaces.add(halfEdge.face.id);
        }
      }
    } else if (this.selectionMode === 'vertex') {
      this.faces.forEach((face, id) => {
        if (face.some(vertexId => this.vertexSelection.has(vertexId))) removedFaces.add(id);
      });
    }
    if (!removedFaces.size) return false;
    this.faces = this.faces.filter((_, id) => !removedFaces.has(id));
    this.clearSelection();
    this.compact();
    return true;
  }

  // Keep the original method name for compatibility with earlier callers.
  deleteSelectedFaces() { return this.deleteSelectedElements(); }

  boundaryForRegion(faceIds) {
    if (!Array.isArray(faceIds) || faceIds.length < 2) return null;
    const edgeUses = new Map();
    for (const faceId of faceIds) {
      const face = this.faces[faceId];
      if (!face || face.length < 3 || new Set(face).size !== face.length) return null;
      for (let i = 0; i < face.length; i++) {
        const a = face[i], b = face[(i + 1) % face.length];
        if (!this.positions[a] || !this.positions[b] || a === b) return null;
        const key = keyFor(a, b);
        if (!edgeUses.has(key)) edgeUses.set(key, []);
        edgeUses.get(key).push({ a, b });
      }
    }

    const boundary = [];
    for (const incidents of edgeUses.values()) {
      if (incidents.length > 2) return null;
      if (incidents.length === 1) boundary.push(incidents[0]);
      else if (incidents[0].a === incidents[1].a && incidents[0].b === incidents[1].b) return null;
    }
    if (boundary.length < 3) return null;

    const outgoing = new Map(), incoming = new Map();
    for (const edge of boundary) {
      if (outgoing.has(edge.a) || incoming.has(edge.b)) return null;
      outgoing.set(edge.a, edge.b);
      incoming.set(edge.b, edge.a);
    }
    if (outgoing.size !== boundary.length || incoming.size !== boundary.length) return null;

    const polygon = [], start = boundary[0].a;
    let current = start;
    for (let i = 0; i < boundary.length; i++) {
      if (!outgoing.has(current) || polygon.includes(current)) return null;
      polygon.push(current);
      current = outgoing.get(current);
      if (current === start) break;
    }
    if (current !== start || polygon.length !== boundary.length) return null;

    // Dissolve can now preserve concave planar boundaries, but still rejects
    // folded, inconsistent, multi-loop, self-intersecting or non-manifold patches.
    const boundaryProjection = projectedPolygon(this.positions, polygon);
    if (!boundaryProjection) return null;
    const origin = this.positions[polygon[0]];
    const scale = Math.max(1, boundaryProjection.scale);
    const tolerance = scale * 1e-5;
    for (const faceId of faceIds) {
      const face = this.faces[faceId];
      const faceProjection = projectedPolygon(this.positions, face);
      if (!faceProjection) return null;
      if (faceProjection.deviation > tolerance) return null;
      if (faceProjection.normal.reduce((sum, value, axis) => sum + value * boundaryProjection.normal[axis], 0) < 0.999) return null;
      for (const vertexId of face) {
        const point = this.positions[vertexId];
        const distance = boundaryProjection.normal.reduce((sum, value, axis) => sum + value * (point[axis] - origin[axis]), 0);
        if (Math.abs(distance) > tolerance) return null;
      }
    }
    return triangulatePolygon(this.positions, polygon) ? polygon : null;
  }

  dissolveSelected() {
    const mode = this.selectionMode;
    const selectedFaces = new Set();
    const parent = this.faces.map((_, id) => id);
    const find = id => {
      while (parent[id] !== id) { parent[id] = parent[parent[id]]; id = parent[id]; }
      return id;
    };
    const join = (a, b) => { const ra = find(a), rb = find(b); if (ra !== rb) parent[rb] = ra; };

    if (mode === 'face') {
      for (const id of this.faceSelection) if (this.faces[id]) selectedFaces.add(id);
      if (selectedFaces.size < 2) return false;
      for (const edge of this.edges) {
        const adjacent = edge.halfEdges.map(halfEdge => halfEdge.face?.id).filter(id => selectedFaces.has(id));
        if (adjacent.length === 2) join(adjacent[0], adjacent[1]);
      }
    } else if (mode === 'edge') {
      if (!this.edgeSelection.size) return false;
      for (const edgeId of this.edgeSelection) {
        const adjacent = (this.edges[edgeId]?.halfEdges || []).map(halfEdge => halfEdge.face?.id);
        if (adjacent.length !== 2 || adjacent.some(id => !Number.isInteger(id))) continue;
        selectedFaces.add(adjacent[0]);
        selectedFaces.add(adjacent[1]);
        join(adjacent[0], adjacent[1]);
      }
    } else if (mode === 'vertex') {
      if (!this.vertexSelection.size) return false;
      for (const vertexId of this.vertexSelection) {
        const adjacent = [];
        this.faces.forEach((face, id) => { if (face.includes(vertexId)) adjacent.push(id); });
        adjacent.forEach(id => selectedFaces.add(id));
        for (let i = 1; i < adjacent.length; i++) join(adjacent[0], adjacent[i]);
      }
    } else return false;

    const components = new Map();
    for (const faceId of selectedFaces) {
      const root = find(faceId);
      if (!components.has(root)) components.set(root, []);
      components.get(root).push(faceId);
    }
    const groups = [];
    for (const ids of components.values()) {
      if (ids.length < 2) continue;
      const polygon = this.boundaryForRegion(ids);
      if (!polygon) continue;
      // A boundary vertex cannot be dissolved by replacing the incident patch.
      if (mode === 'vertex' && [...this.vertexSelection].some(id => polygon.includes(id))) continue;
      groups.push({ ids: ids.sort((a, b) => a - b), polygon });
    }
    if (!groups.length) return false;

    const replacements = new Map(), removed = new Set();
    for (const group of groups) {
      replacements.set(group.ids[0], group);
      group.ids.forEach(id => removed.add(id));
    }
    const nextFaces = [], mergedFaceIds = [], boundaryVertices = new Set();
    for (let id = 0; id < this.faces.length; id++) {
      const group = replacements.get(id);
      if (group) {
        mergedFaceIds.push(nextFaces.length);
        nextFaces.push([...group.polygon]);
        group.polygon.forEach(vertexId => boundaryVertices.add(vertexId));
      } else if (!removed.has(id)) nextFaces.push([...this.faces[id]]);
    }

    this.faces = nextFaces;
    this.clearSelection();
    const remap = this.compact();
    if (mode === 'face') {
      for (const id of mergedFaceIds) this.faceSelection.add(id);
    } else if (mode === 'vertex') {
      for (const id of boundaryVertices) {
        const mapped = remap.get(id);
        if (Number.isInteger(mapped)) this.vertexSelection.add(mapped);
      }
    } else {
      const edgeIds = new Map(this.edges.map(edge => [keyFor(...edge.vertices), edge.id]));
      for (const group of groups) {
        const ring = group.polygon.map(id => remap.get(id));
        for (let i = 0; i < ring.length; i++) {
          const edgeId = edgeIds.get(keyFor(ring[i], ring[(i + 1) % ring.length]));
          if (edgeId !== undefined) this.edgeSelection.add(edgeId);
        }
      }
    }
    return true;
  }


  collectEdgeLoop(seedEdgeIds) {
    const edgeByKey = new Map(this.edges.map(edge => [keyFor(...edge.vertices), edge.id]));
    const visited = new Set(seedEdgeIds), queue = [...seedEdgeIds];
    for (let cursor = 0; cursor < queue.length; cursor++) {
      const edge = this.edges[queue[cursor]];
      if (!edge) continue;
      for (const halfEdge of edge.halfEdges) {
        const face = this.faces[halfEdge.face?.id];
        if (!face || face.length !== 4) continue;
        let side = -1;
        for (let i = 0; i < 4; i++) {
          if (keyFor(face[i], face[(i + 1) % 4]) === keyFor(...edge.vertices)) { side = i; break; }
        }
        if (side < 0) continue;
        const opposite = edgeByKey.get(keyFor(face[(side + 2) % 4], face[(side + 3) % 4]));
        if (opposite !== undefined && !visited.has(opposite)) { visited.add(opposite); queue.push(opposite); }
      }
    }
    return visited;
  }

  expandEdgeLoopSelection({ extend = true } = {}) {
    if (this.selectionMode !== 'edge' || !this.edgeSelection.size) return 0;
    const visited = this.collectEdgeLoop([...this.edgeSelection]);
    if (!extend) this.edgeSelection.clear();
    for (const id of visited) this.edgeSelection.add(id);
    return visited.size;
  }

  /**
   * Transactionally bevels one edge, one supported adjacent pair, or up to
   * eight pairwise-disjoint interior edges. The adjacent-pair path constructs
   * one shared-face miter; longer connected selections are rejected.
   */
  bevelSelectedEdges({ amount = 0.25 } = {}) {
    const fail = reason => ({ changed: false, reason });
    if (this.selectionMode !== 'edge' || this.edgeSelection.size < 1 || this.edgeSelection.size > 8) {
      return fail('Select between one and eight edges in Edge Select mode.');
    }
    if (this.edgeSelection.size === 1) return this.bevelSelectedEdge({ amount });
    if (!Number.isFinite(amount) || amount <= 0 || amount > 0.95) {
      return fail('Bevel amount must be greater than 0 and no more than 0.95.');
    }
    const sharedSelections = [...this.edgeSelection];
    if (sharedSelections.length === 2) {
      const firstEdge = this.edges[sharedSelections[0]], secondEdge = this.edges[sharedSelections[1]];
      const sharedVertices = firstEdge && secondEdge
        ? firstEdge.vertices.filter(vertexId => secondEdge.vertices.includes(vertexId)) : [];
      if (sharedVertices.length) return this.bevelSelectedAdjacentPair({ amount, edgeIds: sharedSelections, sharedVertexId: sharedVertices[0] });
    }
    if (sharedSelections.length > 2) {
      // If the selection contains connected edges, accept only a collection of
      // disjoint two-edge miter pairs. Longer paths, shared junction vertices,
      // and branch components stay rejected until their cap construction has
      // its own independently validated topology template.
      const remaining = new Set(sharedSelections);
      const components = [];
      while (remaining.size) {
        const seed = remaining.values().next().value;
        const component = new Set([seed]);
        const queue = [seed];
        remaining.delete(seed);
        for (let cursor = 0; cursor < queue.length; cursor++) {
          const current = this.edges[queue[cursor]];
          if (!current) return fail('A selected bevel edge could not be resolved.');
          for (const candidateId of [...remaining]) {
            const candidate = this.edges[candidateId];
            if (!candidate) return fail('A selected bevel edge could not be resolved.');
            if (current.vertices.some(vertexId => candidate.vertices.includes(vertexId))) {
              remaining.delete(candidateId);
              component.add(candidateId);
              queue.push(candidateId);
            }
          }
        }
        components.push([...component]);
      }
      if (components.some(component => component.length > 1)) {
        if (components.every(component => component.length === 2)) {
          return this.bevelSelectedAdjacentPairs({ amount, edgePairs: components });
        }
        return fail('Connected multi-edge Bevel currently accepts only separate two-edge miter pairs; longer chains and branches are rejected.');
      }
    }
    const sourceReport = this.validateTopology();
    if (!sourceReport.valid) return fail('The mesh has existing topology warnings. Validate and repair safe issues before beveling.');

    const occupiedVertices = new Set();
    const occupiedFaces = new Set();
    const occupiedCutEdges = new Set();
    const sourceRefs = [];
    for (const edgeId of this.edgeSelection) {
      const edge = this.edges[edgeId];
      if (!edge || edge.halfEdges.length !== 2 || !edge.halfEdges.every(halfEdge => halfEdge.twin)) {
        return fail('Multi-edge Bevel requires closed interior manifold edges only.');
      }
      const [first, second] = edge.halfEdges;
      if (first.next.origin !== second.origin || second.next.origin !== first.origin || first.twin !== second || second.twin !== first) {
        return fail('A selected edge has inconsistent face winding. Repair or orient the mesh before beveling.');
      }
      const endpoints = edge.vertices;
      const localFaces = new Set([first.face?.id, second.face?.id]);
      if (localFaces.has(undefined) || localFaces.size !== 2) return fail('A selected edge has an ambiguous adjacent face pair.');
      const localCutEdges = new Set();
      for (const vertexId of endpoints) {
        const incidentFaces = this.faces.reduce((ids, face, faceId) => {
          if (face.includes(vertexId)) ids.push(faceId);
          return ids;
        }, []);
        const incidentEdges = this.edges.filter(item => item.vertices.includes(vertexId));
        if (incidentFaces.length !== 3 || incidentEdges.length !== 3 || incidentEdges.some(item => item.halfEdges.length !== 2)) {
          return fail('Multi-edge Bevel currently supports closed valence-three corners only.');
        }
        const thirdFaces = incidentFaces.filter(id => !localFaces.has(id));
        if (thirdFaces.length !== 1) return fail('A selected edge has an ambiguous three-face endpoint fan.');
        localFaces.add(thirdFaces[0]);
        for (const item of incidentEdges) {
          if (item.id !== edgeId) localCutEdges.add(item.id);
        }
        if (occupiedVertices.has(vertexId)) return fail('Selected bevel neighborhoods share an endpoint; only exactly two adjacent edges at one common corner are supported in connected mode.');
      }
      if (localFaces.size !== 4) return fail('A selected edge does not have four distinct affected faces.');
      if ([...localFaces].some(id => occupiedFaces.has(id))) {
        return fail('Selected bevel neighborhoods share a face and cannot be separated safely.');
      }
      if ([...localCutEdges].some(id => occupiedCutEdges.has(id))) {
        return fail('Selected bevel neighborhoods share an offset edge and cannot be separated safely.');
      }
      endpoints.forEach(id => occupiedVertices.add(id));
      localFaces.forEach(id => occupiedFaces.add(id));
      localCutEdges.forEach(id => occupiedCutEdges.add(id));
      const points = endpoints.map(id => [...this.positions[id]]);
      const pointKey = point => JSON.stringify(point);
      sourceRefs.push(points.map(pointKey));
    }

    // Endpoint coordinates are used only as stable references across the
    // temporary single-edge rebuilds. Reject duplicate coordinates rather
    // than guessing which disconnected vertex instance should be bevelled.
    const originalPointCounts = new Map();
    this.positions.forEach(point => {
      const key = JSON.stringify(point);
      originalPointCounts.set(key, (originalPointCounts.get(key) || 0) + 1);
    });
    if (sourceRefs.flat().some(key => originalPointCounts.get(key) !== 1)) {
      return fail('Selected edges have duplicate-position endpoint vertices; unique topology references are required.');
    }

    const candidate = new HalfEdgeMesh(this.positions, this.faces);
    const edgeIdFromPointRefs = refs => {
      const verticesByPoint = new Map();
      candidate.positions.forEach((point, id) => {
        const key = JSON.stringify(point);
        if (!verticesByPoint.has(key)) verticesByPoint.set(key, []);
        verticesByPoint.get(key).push(id);
      });
      const aIds = verticesByPoint.get(refs[0]) || [], bIds = verticesByPoint.get(refs[1]) || [];
      if (aIds.length !== 1 || bIds.length !== 1) return null;
      const key = keyFor(aIds[0], bIds[0]);
      const matches = candidate.edges.filter(item => keyFor(...item.vertices) === key);
      return matches.length === 1 ? matches[0].id : null;
    };
    const selectedPerimeterKeys = [];
    const widths = [];
    let insertedVertices = 0;
    let createdFaces = 0;

    for (const refs of sourceRefs) {
      const edgeId = edgeIdFromPointRefs(refs);
      if (!Number.isInteger(edgeId)) return fail('A selected edge could not be found after rebuilding a separate bevel preview.');
      candidate.selectionMode = 'edge';
      candidate.clearSelection();
      candidate.edgeSelection.add(edgeId);
      const result = candidate.bevelSelectedEdge({ amount });
      if (!result.changed) return fail(`Multi-edge Bevel was cancelled: ${result.reason}`);
      widths.push(result.width);
      insertedVertices += result.insertedVertices;
      createdFaces += result.createdFaces;
      for (const selectedId of candidate.edgeSelection) {
        const selectedEdge = candidate.edges[selectedId];
        if (!selectedEdge) return fail('A bevel perimeter edge could not be recovered.');
        const points = selectedEdge.vertices.map(id => JSON.stringify(candidate.positions[id])).sort();
        selectedPerimeterKeys.push(points.join('|'));
      }
    }

    const report = candidate.validateTopology();
    if (!report.valid) return fail(`Combined bevel failed topology validation (${report.issueCount} issue(s)); the original mesh was not changed.`);
    const finalEdgesByPointKey = new Map();
    candidate.edges.forEach(edge => {
      const points = edge.vertices.map(id => JSON.stringify(candidate.positions[id])).sort();
      const key = points.join('|');
      if (!finalEdgesByPointKey.has(key)) finalEdgesByPointKey.set(key, []);
      finalEdgesByPointKey.get(key).push(edge.id);
    });
    candidate.selectionMode = 'edge';
    candidate.clearSelection();
    for (const key of selectedPerimeterKeys) {
      const ids = finalEdgesByPointKey.get(key) || [];
      if (ids.length === 1) candidate.edgeSelection.add(ids[0]);
    }
    if (candidate.edgeSelection.size !== selectedPerimeterKeys.length || candidate.edgeSelection.size !== sourceRefs.length * 4) {
      return fail('The combined bevel perimeter was ambiguous; the original mesh was not changed.');
    }

    this.positions = candidate.positions.map(point => [...point]);
    this.faces = candidate.faces.map(face => [...face]);
    this.selectionMode = 'edge';
    this.clearSelection();
    this.rebuild();
    // Rebuild order is deterministic for identical positions/faces, so the
    // candidate's already-validated edge IDs map directly to this mesh.
    this.edgeSelection = new Set(candidate.edgeSelection);
    return {
      changed: true,
      amount,
      bevelCount: sourceRefs.length,
      width: widths.reduce((sum, width) => sum + width, 0) / widths.length,
      widths,
      insertedVertices,
      createdFaces,
      selectedEdges: this.edgeSelection.size
    };
  }

  /**
   * Applies multiple independent two-edge miter junctions in one transaction.
   * Every pair is preflighted against the immutable source; their affected
   * face neighborhoods must be disjoint. Each pair is then rebuilt on one
   * temporary candidate and the combined result is validated before commit.
   */
  bevelSelectedAdjacentPairs({ amount = 0.25, edgePairs = [] } = {}) {
    const fail = reason => ({ changed: false, reason });
    if (this.selectionMode !== 'edge' || !Number.isFinite(amount) || amount <= 0 || amount > 0.95 ||
        !Array.isArray(edgePairs) || edgePairs.length < 2 || edgePairs.length > 4 ||
        edgePairs.some(pair => !Array.isArray(pair) || pair.length !== 2)) {
      return fail('Multi-junction Bevel requires two to four separate two-edge miter pairs and a width factor from 0–0.95.');
    }
    const sourceReport = this.validateTopology();
    if (!sourceReport.valid) return fail('The mesh has existing topology warnings. Validate and repair safe issues before beveling.');

    const allEndpointIds = new Set();
    const occupiedFaces = new Set();
    const pairRefs = [];
    const pointCounts = new Map();
    this.positions.forEach(point => {
      const key = JSON.stringify(point);
      pointCounts.set(key, (pointCounts.get(key) || 0) + 1);
    });

    for (const pair of edgePairs) {
      const [first, second] = pair.map(id => this.edges[id]);
      if (!first || !second || first.id === second.id) return fail('A miter pair contains an unresolved or duplicated edge.');
      const shared = first.vertices.filter(id => second.vertices.includes(id));
      if (shared.length !== 1) return fail('Each miter pair must contain exactly two edges sharing one endpoint.');
      const center = shared[0];
      const outer = [...first.vertices, ...second.vertices].filter(id => id !== center);
      if (outer.length !== 2 || outer[0] === outer[1]) return fail('A miter pair has ambiguous outer endpoints.');
      const endpointIds = [center, ...outer];
      if (endpointIds.some(id => allEndpointIds.has(id))) {
        return fail('Separate miter pairs cannot share vertices. Connected chains and branching junctions remain unsupported.');
      }

      const localFaces = new Set();
      for (const vertexId of endpointIds) {
        const incidentFaces = this.faces.reduce((ids, face, faceId) => {
          if (face.includes(vertexId)) ids.push(faceId);
          return ids;
        }, []);
        const incidentEdges = this.edges.filter(edge => edge.vertices.includes(vertexId));
        if (incidentFaces.length !== 3 || incidentEdges.length !== 3 ||
            incidentEdges.some(edge => edge.halfEdges.length !== 2 || !edge.halfEdges.every(halfEdge => halfEdge.twin))) {
          return fail('Every miter junction and outer endpoint must have a closed valence-three fan.');
        }
        incidentFaces.forEach(id => localFaces.add(id));
      }
      if ([...localFaces].some(id => occupiedFaces.has(id))) {
        return fail('Separate miter pairs share affected faces; their offset neighborhoods cannot be combined safely.');
      }
      for (const vertexId of endpointIds) {
        const key = JSON.stringify(this.positions[vertexId]);
        if (pointCounts.get(key) !== 1) {
          return fail('Miter endpoint positions must be unique so later pairs can be resolved without guessing.');
        }
        allEndpointIds.add(vertexId);
      }
      localFaces.forEach(id => occupiedFaces.add(id));
      pairRefs.push({
        edgePoints: pair.map(id => this.edges[id].vertices.map(vertexId => JSON.stringify(this.positions[vertexId]))),
        centerPoint: JSON.stringify(this.positions[center])
      });
    }

    const candidate = new HalfEdgeMesh(this.positions, this.faces);
    const findVertex = pointKey => {
      const matches = [];
      candidate.positions.forEach((point, id) => {
        if (JSON.stringify(point) === pointKey) matches.push(id);
      });
      return matches.length === 1 ? matches[0] : null;
    };
    const findEdge = pointRefs => {
      const a = findVertex(pointRefs[0]), b = findVertex(pointRefs[1]);
      if (!Number.isInteger(a) || !Number.isInteger(b)) return null;
      const matches = candidate.edges.filter(edge => keyFor(...edge.vertices) === keyFor(a, b));
      return matches.length === 1 ? matches[0].id : null;
    };
    const selectedPerimeterKeys = [];
    const widths = [];
    let insertedVertices = 0;
    let createdFaces = 0;
    let miterEdges = 0;

    for (const refs of pairRefs) {
      const edgeIds = refs.edgePoints.map(findEdge);
      const center = findVertex(refs.centerPoint);
      if (edgeIds.some(id => !Number.isInteger(id)) || !Number.isInteger(center)) {
        return fail('A later miter pair could not be resolved after rebuilding an earlier independent junction.');
      }
      candidate.selectionMode = 'edge';
      const result = candidate.bevelSelectedAdjacentPair({ amount, edgeIds, sharedVertexId: center });
      if (!result.changed) return fail(`Combined miter preview was cancelled: ${result.reason}`);
      widths.push(result.width);
      insertedVertices += result.insertedVertices;
      createdFaces += result.createdFaces;
      miterEdges += result.miterEdges;
      for (const edgeId of candidate.edgeSelection) {
        const edge = candidate.edges[edgeId];
        if (!edge) return fail('A connected bevel perimeter edge could not be recovered.');
        const points = edge.vertices.map(id => JSON.stringify(candidate.positions[id])).sort();
        selectedPerimeterKeys.push(points.join('|'));
      }
    }

    const report = candidate.validateTopology();
    if (!report.valid) return fail(`Combined miter junctions failed topology validation (${report.issueCount} issue(s)); the original mesh was not changed.`);
    const edgesByPointKey = new Map();
    candidate.edges.forEach(edge => {
      const points = edge.vertices.map(id => JSON.stringify(candidate.positions[id])).sort();
      const key = points.join('|');
      if (!edgesByPointKey.has(key)) edgesByPointKey.set(key, []);
      edgesByPointKey.get(key).push(edge.id);
    });
    candidate.selectionMode = 'edge';
    candidate.clearSelection();
    for (const key of selectedPerimeterKeys) {
      const ids = edgesByPointKey.get(key) || [];
      if (ids.length === 1) candidate.edgeSelection.add(ids[0]);
    }
    const expectedPerimeterEdges = pairRefs.length * 6;
    if (candidate.edgeSelection.size !== expectedPerimeterEdges || selectedPerimeterKeys.length !== expectedPerimeterEdges) {
      return fail('The combined miter perimeter was ambiguous; the original mesh was not changed.');
    }

    this.positions = candidate.positions.map(point => [...point]);
    this.faces = candidate.faces.map(face => [...face]);
    this.selectionMode = 'edge';
    this.clearSelection();
    this.rebuild();
    // Topology rebuild order is deterministic for identical positions/faces.
    // The candidate's perimeter edge IDs therefore map directly to this mesh.
    this.edgeSelection = new Set(candidate.edgeSelection);
    return {
      changed: true,
      amount,
      bevelCount: pairRefs.length * 2,
      miterCount: pairRefs.length,
      width: widths.reduce((sum, width) => sum + width, 0) / widths.length,
      widths,
      insertedVertices,
      createdFaces,
      miterEdges,
      selectedEdges: this.edgeSelection.size
    };
  }

  /**
   * Bevels exactly two adjacent edges around one closed tri-valent corner.
   * The two strip faces share a computed miter edge. All source faces are
   * rebuilt from the immutable input and the candidate is validated before
   * the editable mesh is replaced.
   */
  bevelSelectedAdjacentPair({ amount = 0.25, edgeIds = [...this.edgeSelection], sharedVertexId = null } = {}) {
    const fail = reason => ({ changed: false, reason });
    if (this.selectionMode !== 'edge' || edgeIds.length !== 2 || !Number.isFinite(amount) || amount <= 0 || amount > 0.95) {
      return fail('Connected Bevel requires exactly two selected edges and a width factor from 0–0.95.');
    }
    const [edgeA, edgeB] = edgeIds.map(id => this.edges[id]);
    if (!edgeA || !edgeB) return fail('A selected bevel edge could not be resolved.');
    const commonVertices = edgeA.vertices.filter(id => edgeB.vertices.includes(id));
    if (commonVertices.length !== 1 || (sharedVertexId !== null && commonVertices[0] !== sharedVertexId)) {
      return fail('Connected Bevel requires two edges sharing exactly one endpoint.');
    }
    const center = commonVertices[0];
    const outerVertices = [...edgeA.vertices, ...edgeB.vertices].filter(id => id !== center);
    if (outerVertices.length !== 2 || outerVertices[0] === outerVertices[1]) {
      return fail('The adjacent edge pair has ambiguous outer endpoints.');
    }
    const sourceReport = this.validateTopology();
    if (!sourceReport.valid) return fail('The mesh has existing topology warnings. Validate and repair safe issues before beveling.');

    const edgeByKey = new Map(this.edges.map(edge => [keyFor(...edge.vertices), edge]));
    const edgeIdFor = (a, b) => edgeByKey.get(keyFor(a, b))?.id;
    const selectedEdgeIds = new Set(edgeIds);
    const incidentEdgesByVertex = new Map();
    const affectedFaceIds = new Set();
    for (const vertexId of [center, ...outerVertices]) {
      const incidentFaces = this.faces.reduce((ids, face, faceId) => {
        if (face.includes(vertexId)) ids.push(faceId);
        return ids;
      }, []);
      const incidentEdges = this.edges.filter(edge => edge.vertices.includes(vertexId));
      if (incidentFaces.length !== 3 || incidentEdges.length !== 3 ||
          incidentEdges.some(edge => edge.halfEdges.length !== 2 || !edge.halfEdges.every(halfEdge => halfEdge.twin))) {
        return fail('Connected Bevel currently supports closed valence-three endpoint fans only.');
      }
      incidentEdgesByVertex.set(vertexId, incidentEdges);
      incidentFaces.forEach(id => affectedFaceIds.add(id));
    }

    const isPlanarConvex = (face, positions = this.positions) => {
      const projection = projectedPolygon(positions, face);
      if (!projection || projection.deviation > projection.scale * 1e-5 || !triangulatePolygon(positions, face)) return false;
      const area = signedArea2D(projection.points), winding = Math.sign(area);
      if (!winding) return false;
      const epsilon = projection.scale * projection.scale * 1e-9;
      return projection.points.every((_, index) => cross2(
        projection.points[(index - 1 + projection.points.length) % projection.points.length],
        projection.points[index], projection.points[(index + 1) % projection.points.length]
      ) * winding > epsilon);
    };
    for (const faceId of affectedFaceIds) {
      if (!isPlanarConvex(this.faces[faceId])) return fail('All faces around both bevel endpoints must be simple, planar and convex.');
    }

    const inspectEdge = edge => {
      if (edge.halfEdges.length !== 2) return null;
      let [first, second] = edge.halfEdges;
      if (!first.twin || !second.twin || first.twin !== second || second.twin !== first ||
          first.next.origin !== second.origin || second.next.origin !== first.origin) return null;
      if (first.origin !== center) [first, second] = [second, first];
      const cutInfo = (halfEdge, atStart) => {
        const vertexId = atStart ? halfEdge.origin : halfEdge.next.origin;
        const adjacentHalfEdge = atStart ? halfEdge.prev : halfEdge.next;
        const adjacent = this.edges[adjacentHalfEdge.edge.id];
        if (!adjacent || adjacent.halfEdges.length !== 2 || !adjacent.halfEdges.every(item => item.twin)) return null;
        const otherId = adjacent.vertices[0] === vertexId ? adjacent.vertices[1] : adjacent.vertices[0];
        const from = this.positions[vertexId], to = this.positions[otherId];
        if (!from || !to) return null;
        const length = Math.hypot(to[0] - from[0], to[1] - from[1], to[2] - from[2]);
        if (!Number.isFinite(length) || length <= 1e-10) return null;
        return { vertexId, edgeId: adjacent.id, otherId, from, to, length };
      };
      const start = first.origin, end = first.next.origin;
      const cuts = [
        cutInfo(first, true), cutInfo(first, false),
        cutInfo(second, true), cutInfo(second, false)
      ];
      if (cuts.some(item => !item)) return null;
      return { edgeId: edge.id, first, second, start, end, faceAId: first.face.id, faceBId: second.face.id, cuts };
    };
    const plans = [inspectEdge(edgeA), inspectEdge(edgeB)];
    if (plans.some(plan => !plan)) return fail('Both selected edges must have consistently wound interior manifold neighborhoods.');

    const sharedFaces = plans[0].first.face.id === plans[1].first.face.id || plans[0].first.face.id === plans[1].second.face.id
      ? [plans[0].first.face.id] : [];
    for (const faceId of [plans[0].second.face.id]) {
      if (plans[1].first.face.id === faceId || plans[1].second.face.id === faceId) sharedFaces.push(faceId);
    }
    const uniqueSharedFaces = [...new Set(sharedFaces)];
    if (uniqueSharedFaces.length !== 1) return fail('The adjacent edges do not have one unambiguous shared face for the miter.');
    const sharedFaceId = uniqueSharedFaces[0];
    const sharedFace = this.faces[sharedFaceId];
    const centralIndex = sharedFace.indexOf(center);
    if (centralIndex < 0) return fail('The shared face does not contain the selected corner.');
    const sharedPrevEdgeId = edgeIdFor(sharedFace[(centralIndex - 1 + sharedFace.length) % sharedFace.length], center);
    const sharedNextEdgeId = edgeIdFor(center, sharedFace[(centralIndex + 1) % sharedFace.length]);
    if (!selectedEdgeIds.has(sharedPrevEdgeId) || !selectedEdgeIds.has(sharedNextEdgeId)) {
      return fail('The two selected edges must be consecutive boundary edges of their shared face.');
    }

    const cutInfoByKey = new Map();
    for (const plan of plans) {
      for (const info of plan.cuts) {
        const key = `${info.vertexId}:${info.edgeId}`;
        const previous = cutInfoByKey.get(key);
        if (previous && (previous.length - info.length > 1e-8 ||
            previous.to.some((value, axis) => Math.abs(value - info.to[axis]) > 1e-8))) {
          return fail('The adjacent bevels disagree on a shared offset edge; no topology was changed.');
        }
        cutInfoByKey.set(key, info);
      }
    }
    const maxWidth = Math.min(...[...cutInfoByKey.values()].map(info => info.length)) * 0.45;
    const width = maxWidth * amount;
    if (!Number.isFinite(width) || width <= 1e-9) return fail('The selected corner is too small for a stable bevel.');

    const nextPositions = this.positions.map(point => [...point]);
    const cutIdByKey = new Map();
    const offsetPoint = info => {
      const ratio = width / info.length;
      if (!(ratio > 0 && ratio < 0.5)) return null;
      const point = info.from.map((value, axis) => value + (info.to[axis] - value) * ratio);
      return point.every(Number.isFinite) ? point : null;
    };
    // The points on the two selected radial edges are consumed by the miter
    // intersection; they are not retained as vertices in the final topology.
    const selectedRadialKeys = new Set([`${center}:${edgeA.id}`, `${center}:${edgeB.id}`]);
    for (const [key, info] of cutInfoByKey) {
      const point = offsetPoint(info);
      if (!point) return fail('The requested bevel width is outside a stable edge range.');
      if (selectedRadialKeys.has(key)) continue;
      cutIdByKey.set(key, nextPositions.push(point) - 1);
    }
    const cutId = (vertexId, edgeId) => cutIdByKey.get(`${vertexId}:${edgeId}`);

    // Intersect the two offset lines in the shared face. Each line is parallel
    // to one selected edge and passes through the cut point on the other edge.
    const edgeAOther = edgeA.vertices.find(id => id !== center);
    const edgeBOther = edgeB.vertices.find(id => id !== center);
    const pointOnA = offsetPoint(cutInfoByKey.get(`${center}:${edgeA.id}`));
    const pointOnB = offsetPoint(cutInfoByKey.get(`${center}:${edgeB.id}`));
    if (!pointOnA || !pointOnB) return fail('The shared corner offsets could not be resolved.');
    const directionA = this.positions[edgeAOther].map((value, axis) => value - this.positions[center][axis]);
    const directionB = this.positions[edgeBOther].map((value, axis) => value - this.positions[center][axis]);
    const normal = newellNormal(this.positions, sharedFace);
    const cross3 = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
    const dot3 = (a, b) => a.reduce((sum, value, axis) => sum + value * b[axis], 0);
    const denominator = normal ? dot3(cross3(directionA, directionB), normal) : 0;
    const scale = Math.max(1, Math.hypot(...directionA) * Math.hypot(...directionB));
    if (!Number.isFinite(denominator) || Math.abs(denominator) <= scale * 1e-8) {
      return fail('The selected corner edges are too close to parallel for a stable miter.');
    }
    const difference = pointOnA.map((value, axis) => value - pointOnB[axis]);
    const parameterA = dot3(cross3(difference, directionB), normal) / denominator;
    const parameterB = dot3(cross3(difference, directionA), normal) / denominator;
    if (!(parameterA > 1e-8 && parameterB > 1e-8)) return fail('The offset lines do not meet inside the selected corner.');
    const miterA = pointOnB.map((value, axis) => value + parameterA * directionA[axis]);
    const miterB = pointOnA.map((value, axis) => value + parameterB * directionB[axis]);
    const mismatch = Math.hypot(...miterA.map((value, axis) => value - miterB[axis]));
    if (mismatch > Math.max(1e-7, width * 1e-5)) return fail('The shared offset lines do not meet at a stable miter point.');
    const miterPoint = miterA.map((value, axis) => (value + miterB[axis]) * 0.5);
    const miterLength = Math.hypot(...miterPoint.map((value, axis) => value - this.positions[center][axis]));
    if (!Number.isFinite(miterLength) || miterLength > width * 4) return fail('The corner requires an excessive miter; reduce the width or bevel the edges separately.');
    const projection = projectedPolygon(this.positions, sharedFace);
    const dropAxis = normal.reduce((best, value, axis) => Math.abs(value) > Math.abs(normal[best]) ? axis : best, 0);
    const project = point => dropAxis === 0 ? [point[1], point[2]] : dropAxis === 1 ? [point[0], point[2]] : [point[0], point[1]];
    const miter2 = project(miterPoint);
    const winding = Math.sign(signedArea2D(projection.points));
    const epsilon = projection.scale * projection.scale * 1e-9;
    if (projection.points.some((point, index) => cross2(point, projection.points[(index + 1) % projection.points.length], miter2) * winding < -epsilon)) {
      return fail('The shared offset lines meet outside the common face.');
    }
    const miterId = nextPositions.push(miterPoint) - 1;

    const nextFaces = [];
    for (let faceId = 0; faceId < this.faces.length; faceId++) {
      const face = this.faces[faceId];
      const output = [];
      const append = id => {
        if (!Number.isInteger(id)) return false;
        if (output.at(-1) !== id) output.push(id);
        return true;
      };
      for (let index = 0; index < face.length; index++) {
        const startVertex = face[index];
        const endVertex = face[(index + 1) % face.length];
        const edgeId = edgeIdFor(startVertex, endVertex);
        if (!Number.isInteger(edgeId)) return fail('An affected face has an unresolved boundary edge.');
        if (selectedEdgeIds.has(edgeId)) {
          const edge = this.edges[edgeId];
          const halfEdge = edge.halfEdges.find(item => item.face.id === faceId && item.origin === startVertex && item.next.origin === endVertex);
          if (!halfEdge) return fail('A selected edge has an inconsistent face-boundary direction.');
          const startPoint = faceId === sharedFaceId && startVertex === center
            ? miterId : cutId(startVertex, halfEdge.prev.edge.id);
          const endPoint = faceId === sharedFaceId && endVertex === center
            ? miterId : cutId(endVertex, halfEdge.next.edge.id);
          if (!append(startPoint) || !append(endPoint)) return fail('A selected bevel side could not be replaced by its offset boundary.');
        } else {
          const startPoint = cutId(startVertex, edgeId) ?? startVertex;
          const endPoint = cutId(endVertex, edgeId) ?? endVertex;
          if (!append(startPoint) || !append(endPoint)) return fail('An adjacent source edge could not be trimmed safely.');
        }
      }
      if (output.length > 1 && output[0] === output.at(-1)) output.pop();
      nextFaces.push(output);
    }

    const bevelFaces = [];
    for (const plan of plans) {
      let pA0 = cutId(plan.start, plan.first.prev.edge.id);
      const pB0 = cutId(plan.end, plan.first.next.edge.id);
      const pB1 = cutId(plan.end, plan.second.prev.edge.id);
      let pA1 = cutId(plan.start, plan.second.next.edge.id);
      if (plan.start === center) {
        if (plan.faceAId === sharedFaceId) pA0 = miterId;
        else if (plan.faceBId === sharedFaceId) pA1 = miterId;
      } else {
        return fail('The connected bevel edge direction could not be normalized around the shared corner.');
      }
      if (![pA0, pB0, pB1, pA1].every(Number.isInteger)) return fail('A bevel strip could not resolve its four corner offsets.');
      const strip = [pB0, pA0, pA1, pB1];
      bevelFaces.push(strip);
      nextFaces.push(strip);
    }

    const candidate = new HalfEdgeMesh(nextPositions, nextFaces);
    const compactMap = candidate.compact();
    const report = candidate.validateTopology();
    if (!report.valid) return fail(`The proposed miter failed topology validation (${report.issueCount} issue(s)); the original mesh was not changed.`);
    for (let faceId = 0; faceId < candidate.faces.length; faceId++) {
      if (!candidate.triangulateFace(faceId).length) return fail('The proposed miter produced a face that could not be triangulated.');
    }
    const affectedFacesRemainConvex = [...affectedFaceIds].every(faceId =>
      isPlanarConvex(candidate.faces[faceId], candidate.positions)
    );
    const bevelFacesArePlanarConvex = bevelFaces.every(face =>
      isPlanarConvex(face.map(id => compactMap.get(id)), candidate.positions)
    );
    if (!affectedFacesRemainConvex || !bevelFacesArePlanarConvex) {
      return fail('The proposed miter must preserve planar, convex affected faces and bevel strips.');
    }

    const thirdEdge = incidentEdgesByVertex.get(center).find(edge => !selectedEdgeIds.has(edge.id));
    const thirdCut = cutId(center, thirdEdge?.id);
    if (!Number.isInteger(thirdCut)) return fail('The shared miter edge could not be resolved.');
    const miterKey = keyFor(compactMap.get(miterId), compactMap.get(thirdCut));
    const perimeterKeys = new Set();
    for (const face of bevelFaces) {
      const mapped = face.map(id => compactMap.get(id));
      for (let index = 0; index < mapped.length; index++) {
        const key = keyFor(mapped[index], mapped[(index + 1) % mapped.length]);
        if (key !== miterKey) perimeterKeys.add(key);
      }
    }
    const edgeIdsByKey = new Map(candidate.edges.map(edge => [keyFor(...edge.vertices), edge.id]));
    candidate.selectionMode = 'edge';
    candidate.clearSelection();
    for (const key of perimeterKeys) {
      const id = edgeIdsByKey.get(key);
      if (id !== undefined) candidate.edgeSelection.add(id);
    }
    const miterEdges = candidate.edges.filter(edge => keyFor(...edge.vertices) === miterKey);
    if (candidate.edgeSelection.size !== 6 || miterEdges.length !== 1 || miterEdges[0].halfEdges.length !== 2) {
      return fail('The miter must contain six selectable perimeter edges and one shared manifold miter edge.');
    }

    this.positions = candidate.positions.map(point => [...point]);
    this.faces = candidate.faces.map(face => [...face]);
    this.selectionMode = 'edge';
    this.clearSelection();
    this.rebuild();
    const committedEdges = new Map(this.edges.map(edge => [keyFor(...edge.vertices), edge.id]));
    for (const key of perimeterKeys) {
      const id = committedEdges.get(key);
      if (id !== undefined) this.edgeSelection.add(id);
    }
    return {
      changed: true,
      amount,
      width,
      maxWidth,
      bevelCount: 2,
      insertedVertices: cutIdByKey.size + 1,
      createdFaces: 2,
      miterEdges: 1,
      selectedEdges: this.edgeSelection.size
    };
  }

  /**
   * Bevels one interior edge on a closed, convex tri-valent neighborhood.
   * This deliberately narrow first pass supports cube-like corners only:
   * both endpoints must have three incident faces, all affected faces must be
   * planar/convex, and every affected edge must be manifold. All topology is
   * built and validated on a temporary mesh before the source is replaced.
   * `amount` is a 0–1 fraction of the maximum safe offset (45% of the shortest
   * adjacent edge), not a world-unit distance.
   */
  bevelSelectedEdge({ amount = 0.25 } = {}) {
    const fail = reason => ({ changed: false, reason });
    if (this.selectionMode !== 'edge' || this.edgeSelection.size !== 1) {
      return fail('Select exactly one edge in Edge Select mode.');
    }
    if (!Number.isFinite(amount) || amount <= 0 || amount > 0.95) {
      return fail('Bevel amount must be greater than 0 and no more than 0.95.');
    }

    const edge = this.edges[[...this.edgeSelection][0]];
    if (!edge || edge.halfEdges.length !== 2 || !edge.halfEdges[0].twin || !edge.halfEdges[1].twin) {
      return fail('Bevel currently requires one closed interior manifold edge; boundary and non-manifold edges are skipped.');
    }
    const [first, second] = edge.halfEdges;
    if (first.next.origin !== second.origin || second.next.origin !== first.origin || first.twin !== second || second.twin !== first) {
      return fail('The selected edge has inconsistent face winding. Repair or orient the mesh before beveling.');
    }

    const sourceReport = this.validateTopology();
    if (!sourceReport.valid) return fail('The mesh has existing topology warnings. Validate and repair safe issues before beveling.');

    const faceAId = first.face?.id, faceBId = second.face?.id;
    const faceA = this.faces[faceAId], faceB = this.faces[faceBId];
    if (!faceA || !faceB || faceAId === faceBId) return fail('The selected edge does not have two distinct adjacent faces.');
    const a = first.origin, b = first.next.origin;
    const affectedFaces = new Set([faceAId, faceBId]);
    const edgeByKey = new Map(this.edges.map(item => [keyFor(...item.vertices), item]));
    const vertices = [a, b];

    for (const vertexId of vertices) {
      const incidentFaces = this.faces.reduce((ids, face, faceId) => {
        if (face.includes(vertexId)) ids.push(faceId);
        return ids;
      }, []);
      const incidentEdges = this.edges.filter(item => item.vertices.includes(vertexId));
      if (incidentFaces.length !== 3 || incidentEdges.length !== 3 || incidentEdges.some(item => item.halfEdges.length !== 2)) {
        return fail('Bevel currently supports closed valence-three corners only; boundary and extraordinary neighborhoods are skipped.');
      }
      const thirdFaces = incidentFaces.filter(id => !affectedFaces.has(id));
      if (thirdFaces.length !== 1) return fail('The selected edge does not have a simple three-face corner fan at both endpoints.');
      const thirdFace = this.faces[thirdFaces[0]];
      if (!thirdFace || thirdFace.length < 3 || !thirdFace.includes(vertexId)) return fail('The adjacent corner face is invalid.');
      affectedFaces.add(thirdFaces[0]);
    }
    if (affectedFaces.size !== 4) return fail('Both edge endpoints must have distinct, unambiguous corner faces.');

    const isPlanarConvex = faceId => {
      const face = this.faces[faceId];
      const projection = projectedPolygon(this.positions, face);
      if (!projection || projection.deviation > projection.scale * 1e-5 || !triangulatePolygon(this.positions, face)) return false;
      const area = signedArea2D(projection.points), winding = Math.sign(area);
      if (!winding) return false;
      const epsilon = projection.scale * projection.scale * 1e-9;
      for (let i = 0; i < projection.points.length; i++) {
        if (cross2(projection.points[(i - 1 + projection.points.length) % projection.points.length],
          projection.points[i], projection.points[(i + 1) % projection.points.length]) * winding <= epsilon) return false;
      }
      return true;
    };
    for (const faceId of affectedFaces) {
      if (!isPlanarConvex(faceId)) return fail('All four faces around this edge must be simple, planar and convex.');
    }

    // Create one cut vertex on each non-selected edge meeting the selected
    // edge's two endpoints. The two remaining corner faces bridge those pairs.
    const adjacentLengths = [];
    const pointAlong = (vertexId, edgeId) => {
      const adjacent = this.edges[edgeId];
      if (!adjacent || adjacent.halfEdges.length !== 2 || !adjacent.halfEdges.every(he => he.twin)) return null;
      const otherId = adjacent.vertices[0] === vertexId ? adjacent.vertices[1] : adjacent.vertices[0];
      const from = this.positions[vertexId], to = this.positions[otherId];
      if (!from || !to) return null;
      const length = Math.hypot(to[0]-from[0], to[1]-from[1], to[2]-from[2]);
      if (!Number.isFinite(length) || length <= 1e-10) return null;
      adjacentLengths.push(length);
      return { edgeId: adjacent.id, otherId, from, to, length };
    };
    const cornerCut = (halfEdge, atStart) => {
      const vertexId = atStart ? halfEdge.origin : halfEdge.next.origin;
      const adjacentHalfEdge = atStart ? halfEdge.prev : halfEdge.next;
      const edgeInfo = pointAlong(vertexId, adjacentHalfEdge.edge.id);
      if (!edgeInfo) return null;
      return { vertexId, edgeId: edgeInfo.edgeId, otherId: edgeInfo.otherId, from: edgeInfo.from, to: edgeInfo.to, length: edgeInfo.length };
    };
    const cutA0 = cornerCut(first, true);   // on the incoming edge of face A at A
    const cutB0 = cornerCut(first, false);  // on the outgoing edge of face A at B
    const cutB1 = cornerCut(second, true);  // on the incoming edge of face B at B
    const cutA1 = cornerCut(second, false); // on the outgoing edge of face B at A
    if (![cutA0, cutB0, cutB1, cutA1].every(Boolean)) {
      return fail('The edge neighborhood is incomplete or contains a boundary edge.');
    }
    const uniqueCuts = new Set([cutA0, cutB0, cutB1, cutA1].map(item => `${item.vertexId}:${item.edgeId}`));
    if (uniqueCuts.size !== 4) return fail('The selected edge has overlapping or ambiguous corner edges.');

    const maxWidth = Math.min(...adjacentLengths) * 0.45;
    const width = maxWidth * amount;
    if (!Number.isFinite(width) || width <= 1e-9) return fail('The selected edge is too small for a stable bevel.');
    const nextPositions = this.positions.map(point => [...point]);
    const cutIdByCornerEdge = new Map();
    const createCut = item => {
      const ratio = width / item.length;
      if (!(ratio > 0 && ratio < 0.5)) return null;
      const point = item.from.map((value, axis) => value + (item.to[axis] - value) * ratio);
      if (!point.every(Number.isFinite)) return null;
      const id = nextPositions.length;
      nextPositions.push(point);
      cutIdByCornerEdge.set(`${item.vertexId}:${item.edgeId}`, id);
      return id;
    };
    const pA0 = createCut(cutA0), pB0 = createCut(cutB0), pB1 = createCut(cutB1), pA1 = createCut(cutA1);
    if (![pA0,pB0,pB1,pA1].every(Number.isInteger)) return fail('The requested bevel width is outside a stable edge range.');

    const trimDirectedFace = (halfEdge, startCut, endCut) => {
      const face = this.faces[halfEdge.face.id], start = halfEdge.origin, end = halfEdge.next.origin;
      const index = face.indexOf(start);
      if (index < 0 || face[(index + 1) % face.length] !== end) return null;
      const rotated = [...face.slice(index), ...face.slice(0, index)];
      return [startCut, endCut, ...rotated.slice(2)];
    };
    const trimCornerFace = (faceId, vertexId) => {
      const face = this.faces[faceId], index = face.indexOf(vertexId);
      if (index < 0) return null;
      const previous = face[(index - 1 + face.length) % face.length];
      const next = face[(index + 1) % face.length];
      const previousEdge = edgeByKey.get(keyFor(previous, vertexId));
      const nextEdge = edgeByKey.get(keyFor(vertexId, next));
      const previousCut = previousEdge && cutIdByCornerEdge.get(`${vertexId}:${previousEdge.id}`);
      const nextCut = nextEdge && cutIdByCornerEdge.get(`${vertexId}:${nextEdge.id}`);
      if (!Number.isInteger(previousCut) || !Number.isInteger(nextCut)) return null;
      return [...face.slice(0, index), previousCut, nextCut, ...face.slice(index + 1)];
    };

    const trimmedA = trimDirectedFace(first, pA0, pB0);
    const trimmedB = trimDirectedFace(second, pB1, pA1);
    if (!trimmedA || !trimmedB) return fail('The adjacent faces do not have a consistent edge neighborhood.');

    const nextFaces = this.faces.map(face => [...face]);
    nextFaces[faceAId] = trimmedA;
    nextFaces[faceBId] = trimmedB;
    for (const vertexId of [a, b]) {
      const incident = [...affectedFaces].filter(faceId => faceId !== faceAId && faceId !== faceBId && this.faces[faceId].includes(vertexId));
      if (incident.length !== 1) return fail('The corner cap face is ambiguous.');
      const cap = trimCornerFace(incident[0], vertexId);
      if (!cap) return fail('The corner cap could not be constructed safely.');
      nextFaces[incident[0]] = cap;
    }
    // Reverse the selected face edge, then bridge both trimmed face strips.
    const bevelFace = [pB0, pA0, pA1, pB1];
    nextFaces.push(bevelFace);

    const candidate = new HalfEdgeMesh(nextPositions, nextFaces);
    const compactMap = candidate.compact();
    const candidateReport = candidate.validateTopology();
    if (!candidateReport.valid) {
      return fail(`The proposed bevel failed topology validation (${candidateReport.issueCount} issue(s)); the original mesh was not changed.`);
    }
    if (candidate.faces.slice(0, nextFaces.length - 1).some((_, faceId) => !candidate.triangulateFace(faceId).length) ||
        !candidate.triangulateFace(candidate.faces.length - 1).length) {
      return fail('The proposed bevel produced a face that could not be triangulated.');
    }

    const selectedRing = [pB0, pA0, pA1, pB1].map(id => compactMap.get(id));
    candidate.selectionMode = 'edge';
    candidate.clearSelection();
    const candidateEdgeIds = new Map(candidate.edges.map(item => [keyFor(...item.vertices), item.id]));
    for (let i = 0; i < selectedRing.length; i++) {
      const edgeId = candidateEdgeIds.get(keyFor(selectedRing[i], selectedRing[(i + 1) % selectedRing.length]));
      if (edgeId !== undefined) candidate.edgeSelection.add(edgeId);
    }
    if (candidate.edgeSelection.size !== 4) return fail('The bevel perimeter did not produce four stable edges.');

    this.positions = candidate.positions.map(point => [...point]);
    this.faces = candidate.faces.map(face => [...face]);
    this.selectionMode = 'edge';
    this.clearSelection();
    this.rebuild();
    const selectedKeys = selectedRing.map((id, index) => keyFor(id, selectedRing[(index + 1) % selectedRing.length]));
    const rebuiltEdgeIds = new Map(this.edges.map(item => [keyFor(...item.vertices), item.id]));
    for (const key of selectedKeys) {
      const edgeId = rebuiltEdgeIds.get(key);
      if (edgeId !== undefined) this.edgeSelection.add(edgeId);
    }
    return { changed: true, amount, width, maxWidth, insertedVertices: 4, createdFaces: 1, selectedEdges: this.edgeSelection.size };
  }

  /**
   * Inserts a centered/interpolated cut through a regular quad edge loop.
   * The operation is transactional: all incident faces are checked before any
   * vertex or face data is changed. Unsupported topology returns a reason.
   */
  cutEdgeLoop({ offset = 0.5, cuts = 1, offsets = null } = {}) {
    if (this.selectionMode !== 'edge' || this.edgeSelection.size !== 1) {
      return { changed: false, reason: 'Select exactly one seed edge in Edge Select mode.' };
    }
    if (!Number.isInteger(cuts) || cuts < 1 || cuts > 8) {
      return { changed: false, reason: 'Loop Cut supports between 1 and 8 cuts per operation.' };
    }
    const requestedOffsets = Array.isArray(offsets) ? [...offsets] :
      Array.from({ length: cuts }, (_, index) => (index + 1) / (cuts + 1) + (offset - 0.5));
    if (requestedOffsets.length !== cuts || requestedOffsets.some(value => !Number.isFinite(value) || value <= 0 || value >= 1)) {
      return { changed: false, reason: 'Every cut must remain strictly inside its source edge.' };
    }
    requestedOffsets.sort((a, b) => a - b);
    if (requestedOffsets.some((value, index) => index > 0 && value - requestedOffsets[index - 1] < 1e-5)) {
      return { changed: false, reason: 'Loop Cut positions are too close together to create stable topology.' };
    }

    const loopEdgeIds = this.collectEdgeLoop([...this.edgeSelection]);
    const loopEdgeSet = new Set(loopEdgeIds);
    const edgeFaces = new Map();
    for (const edgeId of loopEdgeIds) {
      const edge = this.edges[edgeId];
      if (!edge || edge.halfEdges.length < 1 || edge.halfEdges.length > 2) {
        return { changed: false, reason: 'The edge loop touches a non-manifold or detached edge.' };
      }
      edgeFaces.set(edgeId, edge.halfEdges.map(halfEdge => halfEdge.face?.id));
      if (edge.halfEdges.length === 2) {
        const [a, b] = edge.halfEdges;
        if (a.origin !== b.next?.origin || a.next?.origin !== b.origin) {
          return { changed: false, reason: 'The loop touches faces with inconsistent winding.' };
        }
      }
    }

    const edgeByKey = new Map(this.edges.map(edge => [keyFor(...edge.vertices), edge]));
    const splitPlans = [];
    const participatingFaces = new Set();
    for (let faceId = 0; faceId < this.faces.length; faceId++) {
      const face = this.faces[faceId];
      if (!Array.isArray(face) || face.length !== 4) continue;
      const selectedSides = [];
      for (let i = 0; i < 4; i++) {
        const edgeId = edgeByKey.get(keyFor(face[i], face[(i + 1) % 4]))?.id;
        if (edgeId !== undefined && loopEdgeSet.has(edgeId)) selectedSides.push(i);
      }
      if (!selectedSides.length) continue;
      if (selectedSides.length !== 2 || (selectedSides[0] + 2) % 4 !== selectedSides[1]) {
        return { changed: false, reason: 'The loop reaches a quad without exactly two opposite loop edges.' };
      }

      const projection = projectedPolygon(this.positions, face);
      if (!projection || projection.deviation > projection.scale * 1e-5 ||
          polygonSelfIntersects(projection.points, projection.scale * projection.scale * 1e-10) ||
          !triangulatePolygon(this.positions, face)) {
        return { changed: false, reason: 'Loop Cut requires simple, planar quad faces.' };
      }
      const points = projection.points;
      const turns = points.map((point, index) => cross2(point, points[(index + 1) % 4], points[(index + 2) % 4]));
      const epsilon = projection.scale * projection.scale * 1e-10;
      if (!(turns.every(value => value > epsilon) || turns.every(value => value < -epsilon))) {
        return { changed: false, reason: 'Loop Cut requires convex quad faces; concave quads are left unchanged.' };
      }

      const side = selectedSides[0];
      const a = face[side], b = face[(side + 1) % 4];
      const c = face[(side + 2) % 4], d = face[(side + 3) % 4];
      const edgeAB = edgeByKey.get(keyFor(a, b));
      const edgeCD = edgeByKey.get(keyFor(c, d));
      if (!edgeAB || !edgeCD) return { changed: false, reason: 'The selected loop edge could not be resolved in the quad topology.' };
      const signAB = a === edgeAB.vertices[0] ? 1 : -1;
      const signCD = c === edgeCD.vertices[0] ? 1 : -1;
      splitPlans.push({ faceId, face: [...face], side, edgeABId: edgeAB.id, edgeCDId: edgeCD.id, sameEdgeOrientation: signAB === signCD });
      participatingFaces.add(faceId);
    }

    for (const [edgeId, incidentFaceIds] of edgeFaces) {
      if (incidentFaceIds.some(faceId => !Number.isInteger(faceId) || !participatingFaces.has(faceId))) {
        return { changed: false, reason: 'The edge loop reaches a non-quad face or an unsupported boundary.' };
      }
    }
    if (!splitPlans.length) return { changed: false, reason: 'No complete quad strip was found from the selected edge.' };

    // Carry an ordered set of cut fractions across every opposite-edge pair.
    // Reversing canonical edge direction reverses every fraction, then sorting
    // restores the local low-to-high ordering used by the vertex lookup below.
    const parameterAdjacency = new Map([...loopEdgeIds].map(edgeId => [edgeId, []]));
    for (const plan of splitPlans) {
      parameterAdjacency.get(plan.edgeABId)?.push([plan.edgeCDId, plan.sameEdgeOrientation]);
      parameterAdjacency.get(plan.edgeCDId)?.push([plan.edgeABId, plan.sameEdgeOrientation]);
    }
    const seedEdgeId = this.edgeSelection.values().next().value;
    const edgeParameters = new Map([[seedEdgeId, [...requestedOffsets]]]);
    const parameterQueue = [seedEdgeId];
    for (let cursor = 0; cursor < parameterQueue.length; cursor++) {
      const edgeId = parameterQueue[cursor];
      const parameters = edgeParameters.get(edgeId);
      for (const [nextEdgeId, sameEdgeOrientation] of parameterAdjacency.get(edgeId) || []) {
        const nextParameters = (sameEdgeOrientation ? parameters.map(value => 1 - value) : [...parameters]).sort((a, b) => a - b);
        if (!edgeParameters.has(nextEdgeId)) {
          edgeParameters.set(nextEdgeId, nextParameters);
          parameterQueue.push(nextEdgeId);
        } else if (edgeParameters.get(nextEdgeId).some((value, index) => Math.abs(value - nextParameters[index]) > 1e-8)) {
          return { changed: false, reason: 'The loop returns with inconsistent cut offsets; no topology was changed.' };
        }
      }
    }
    if (edgeParameters.size !== loopEdgeSet.size) {
      return { changed: false, reason: 'The cut offsets could not be propagated across the complete loop.' };
    }

    const nextPositions = this.positions.map(position => [...position]);
    const splitVerticesByEdge = new Map();
    for (const edgeId of loopEdgeIds) {
      const [a, b] = this.edges[edgeId].vertices;
      const entries = edgeParameters.get(edgeId).map(parameter => {
        const point = nextPositions[a].map((value, axis) => value + (nextPositions[b][axis] - value) * parameter);
        return { parameter, vertex: nextPositions.push(point) - 1 };
      });
      splitVerticesByEdge.set(edgeId, entries);
    }

    const verticesAlongEdge = (edgeId, fromVertex) => {
      const edge = this.edges[edgeId];
      const entries = splitVerticesByEdge.get(edgeId) || [];
      return (edge.vertices[0] === fromVertex ? entries : [...entries].reverse()).map(entry => entry.vertex);
    };
    const nextFaces = [], cutPairs = [];
    const planByFace = new Map(splitPlans.map(plan => [plan.faceId, plan]));
    for (let faceId = 0; faceId < this.faces.length; faceId++) {
      const plan = planByFace.get(faceId);
      if (!plan) { nextFaces.push([...this.faces[faceId]]); continue; }
      const { face, side } = plan;
      const a = face[side], b = face[(side + 1) % 4];
      const c = face[(side + 2) % 4], d = face[(side + 3) % 4];
      const pAB = verticesAlongEdge(plan.edgeABId, a);
      const pCD = verticesAlongEdge(plan.edgeCDId, c);
      if (pAB.length !== cuts || pCD.length !== cuts) {
        return { changed: false, reason: 'The cut positions could not be mapped consistently across the quad strip.' };
      }

      // The two opposite sides run in opposite spatial directions around the
      // quad. Pair the first point on AB with the last point on CD.
      nextFaces.push([pAB[cuts - 1], b, c, pCD[0]]);
      for (let index = 0; index < cuts - 1; index++) {
        nextFaces.push([pAB[index], pAB[index + 1], pCD[cuts - 2 - index], pCD[cuts - 1 - index]]);
      }
      nextFaces.push([pCD[cuts - 1], d, a, pAB[0]]);
      for (let index = 0; index < cuts; index++) cutPairs.push([pAB[index], pCD[cuts - 1 - index]]);
    }

    this.positions = nextPositions;
    this.faces = nextFaces;
    this.clearSelection();
    this.rebuild();
    const rebuiltEdgeIds = new Map(this.edges.map(edge => [keyFor(...edge.vertices), edge.id]));
    for (const [a, b] of cutPairs) {
      const edgeId = rebuiltEdgeIds.get(keyFor(a, b));
      if (edgeId !== undefined) this.edgeSelection.add(edgeId);
    }
    return {
      changed: true,
      cuts,
      offsets: requestedOffsets,
      insertedVertices: [...splitVerticesByEdge.values()].reduce((sum, entries) => sum + entries.length, 0),
      splitFaces: splitPlans.length,
      createdFaces: splitPlans.length * (cuts + 1),
      createdCutEdges: cutPairs.length,
      selectedCutEdges: this.edgeSelection.size
    };
  }

  orderedVertexFan(vertexId) {
    const start = this.vertices[vertexId]?.halfEdge;
    if (!start || start.origin !== vertexId) return null;
    const fan = [], visited = new Set();
    let current = start;
    while (current && !visited.has(current.id) && fan.length <= this.halfEdges.length) {
      if (current.origin !== vertexId) return null;
      visited.add(current.id);
      fan.push(current);
      current = current.prev?.twin || null;
    }
    return current === start ? fan : null;
  }

  isClosedQuadFan(fan) {
    if (!Array.isArray(fan) || fan.length < 3) return false;
    const edgeIds = new Set();
    for (const halfEdge of fan) {
      if (!halfEdge?.face || this.faces[halfEdge.face.id]?.length !== 4 ||
          !halfEdge.edge || halfEdge.edge.halfEdges.length !== 2 || !halfEdge.twin ||
          edgeIds.has(halfEdge.edge.id)) return false;
      edgeIds.add(halfEdge.edge.id);
    }
    return true;
  }

  /**
   * Finds a geometrically unambiguous continuation through a closed
   * extraordinary all-quad vertex fan. Only near-antiparallel incident edges
   * are paired; weak or tied candidates deliberately stop at the pole.
   */
  oppositeEdgeAtExtraordinaryPole(vertexId, edgeId, fan) {
    if (!this.isClosedQuadFan(fan) || fan.length === 4) return null;
    const origin = this.positions[vertexId];
    if (!origin) return null;
    const candidates = fan.map(halfEdge => halfEdge.edge);
    const direction = edge => {
      const otherId = edge.vertices[0] === vertexId ? edge.vertices[1] : edge.vertices[0];
      const point = this.positions[otherId];
      if (!point) return null;
      const vector = point.map((value, axis) => value - origin[axis]);
      const length = Math.hypot(...vector);
      return length > 1e-10 ? vector.map(value => value / length) : null;
    };
    const vectors = new Map(fan.map(halfEdge => [halfEdge.edge.id, direction(halfEdge.edge)]));
    if (!vectors.get(edgeId)) return null;
    const threshold = -Math.cos(25 * Math.PI / 180); // at least 155 degrees apart
    const uniquenessMargin = 0.15;
    const bestPartner = sourceId => {
      const source = vectors.get(sourceId);
      if (!source) return null;
      const ranked = candidates.filter(edge => edge.id !== sourceId && vectors.get(edge.id))
        .map(edge => ({ id: edge.id, dot: source.reduce((sum, value, axis) => sum + value * vectors.get(edge.id)[axis], 0) }))
        .sort((a, b) => a.dot - b.dot);
      if (!ranked.length || ranked[0].dot > threshold) return null;
      if (ranked[1] && ranked[1].dot - ranked[0].dot < uniquenessMargin) return null;
      return ranked[0].id;
    };
    const partner = bestPartner(edgeId);
    if (partner === null || bestPartner(partner) !== edgeId) return null;
    return partner;
  }

  expandEdgeRingSelection({ extend = true } = {}) {
    if (this.selectionMode !== 'edge' || !this.edgeSelection.size) {
      this.lastRingTraversal = { regularVertices: 0, extraordinaryVertices: 0, ambiguousPoles: 0, stoppedFans: 0 };
      return 0;
    }
    const seeds = [...this.edgeSelection];
    const visited = new Set(seeds), queue = [...seeds];
    const stats = { regularVertices: 0, extraordinaryVertices: 0, ambiguousPoles: 0, stoppedFans: 0 };
    const regularVertexIds = new Set(), extraordinaryVertexIds = new Set();
    const ambiguousPoleIds = new Set(), stoppedFanVertexIds = new Set();
    const processed = new Set();
    while (queue.length) {
      const edge = this.edges[queue.shift()];
      if (!edge) continue;
      for (const vertexId of edge.vertices) {
        const visitKey = `${vertexId}:${edge.id}`;
        if (processed.has(visitKey)) continue;
        processed.add(visitKey);
        const fan = this.orderedVertexFan(vertexId);
        if (!this.isClosedQuadFan(fan)) { stoppedFanVertexIds.add(vertexId); continue; }
        const currentIndex = fan.findIndex(halfEdge => halfEdge.edge.id === edge.id);
        if (currentIndex < 0) continue;
        let opposite;
        if (fan.length === 4) {
          regularVertexIds.add(vertexId);
          opposite = fan[(currentIndex + 2) % 4].edge.id;
        } else {
          opposite = this.oppositeEdgeAtExtraordinaryPole(vertexId, edge.id, fan);
          if (opposite === null) { ambiguousPoleIds.add(vertexId); continue; }
          extraordinaryVertexIds.add(vertexId);
        }
        if (!visited.has(opposite)) { visited.add(opposite); queue.push(opposite); }
      }
    }
    stats.regularVertices = regularVertexIds.size;
    stats.extraordinaryVertices = extraordinaryVertexIds.size;
    stats.ambiguousPoles = ambiguousPoleIds.size;
    stats.stoppedFans = stoppedFanVertexIds.size;
    this.lastRingTraversal = stats;
    if (!extend) this.edgeSelection.clear();
    for (const id of visited) this.edgeSelection.add(id);
    return visited.size;
  }

  validateTopology() {
    const invalidPositions = [], invalidFaces = [], duplicateFaces = [], nonManifoldEdges = [];
    const inconsistentWinding = [], isolatedVertices = [], nonPlanarFaces = [];
    const selfIntersectingFaces = [], triangulationFailures = [];
    const edgeUses = new Map(), usedVertices = new Set(), faceKeys = new Set();
    this.positions.forEach((position, id) => {
      if (!Array.isArray(position) || position.length < 3 || !position.slice(0, 3).every(Number.isFinite)) invalidPositions.push(id);
    });
    const invalidPositionSet = new Set(invalidPositions);
    this.faces.forEach((face, faceId) => {
      if (!Array.isArray(face) || face.length < 3 || new Set(face).size !== face.length ||
          face.some(id => !Number.isInteger(id) || id < 0 || id >= this.positions.length || invalidPositionSet.has(id))) {
        invalidFaces.push(faceId);
        return;
      }
      face.forEach(id => usedVertices.add(id));
      const canonical = [...face].sort((a, b) => a - b).join(':');
      if (faceKeys.has(canonical)) duplicateFaces.push(faceId); else faceKeys.add(canonical);
      for (let i = 0; i < face.length; i++) {
        const a = face[i], b = face[(i + 1) % face.length], key = keyFor(a, b);
        if (!edgeUses.has(key)) edgeUses.set(key, []);
        edgeUses.get(key).push({ a, b });
      }
      const projection = projectedPolygon(this.positions, face);
      if (!projection) { invalidFaces.push(faceId); triangulationFailures.push(faceId); return; }
      const tolerance = projection.scale * 1e-5;
      if (projection.deviation > tolerance) nonPlanarFaces.push({ faceId, deviation: projection.deviation, tolerance });
      if (polygonSelfIntersects(projection.points, projection.scale * projection.scale * 1e-10)) selfIntersectingFaces.push(faceId);
      if (!triangulatePolygon(this.positions, face)) triangulationFailures.push(faceId);
    });
    for (const [key, incidents] of edgeUses) {
      if (incidents.length > 2) nonManifoldEdges.push(key);
      else if (incidents.length === 2 && incidents[0].a === incidents[1].a && incidents[0].b === incidents[1].b) inconsistentWinding.push(key);
    }
    for (let id = 0; id < this.positions.length; id++) if (!usedVertices.has(id)) isolatedVertices.push(id);
    const boundaryEdges = [...edgeUses.values()].filter(incidents => incidents.length === 1).length;
    const counts = {
      invalidPositions: invalidPositions.length, invalidFaces: invalidFaces.length,
      duplicateFaces: duplicateFaces.length, nonManifoldEdges: nonManifoldEdges.length,
      inconsistentWinding: inconsistentWinding.length, isolatedVertices: isolatedVertices.length,
      nonPlanarFaces: nonPlanarFaces.length, selfIntersectingFaces: selfIntersectingFaces.length,
      triangulationFailures: triangulationFailures.length, boundaryEdges
    };
    const issueCount = counts.invalidPositions + counts.invalidFaces + counts.duplicateFaces +
      counts.nonManifoldEdges + counts.inconsistentWinding + counts.isolatedVertices +
      counts.nonPlanarFaces + counts.selfIntersectingFaces + counts.triangulationFailures;
    return {
      valid: issueCount === 0, issueCount, counts,
      details: { invalidPositions, invalidFaces, duplicateFaces, nonManifoldEdges,
        inconsistentWinding, isolatedVertices, nonPlanarFaces, selfIntersectingFaces, triangulationFailures }
    };
  }

  repairTopology() {
    const before = this.validateTopology();
    const invalidPositionSet = new Set(before.details.invalidPositions);
    const kept = [], seen = new Set();
    let removedInvalidFaces = 0, removedDuplicateFaces = 0;
    for (const face of this.faces) {
      const valid = Array.isArray(face) && face.length >= 3 && new Set(face).size === face.length &&
        face.every(id => Number.isInteger(id) && id >= 0 && id < this.positions.length && !invalidPositionSet.has(id));
      if (!valid) { removedInvalidFaces++; continue; }
      const key = [...face].sort((a,b)=>a-b).join(':');
      if (seen.has(key)) { removedDuplicateFaces++; continue; }
      seen.add(key); kept.push([...face]);
    }

    // Reorient only closed, manifold-connected face components. Components touching
    // an edge with >2 incident faces are deliberately left untouched.
    const uses = new Map();
    kept.forEach((face, faceId) => face.forEach((a, i) => {
      const b = face[(i+1)%face.length], key = keyFor(a,b);
      if (!uses.has(key)) uses.set(key, []);
      uses.get(key).push({ faceId, a, b });
    }));
    const adjacency = kept.map(() => []), blocked = new Set();
    for (const incidents of uses.values()) {
      if (incidents.length > 2) { incidents.forEach(item => blocked.add(item.faceId)); continue; }
      if (incidents.length !== 2) continue;
      const [a,b] = incidents;
      const sameDirection = a.a === b.a && a.b === b.b;
      adjacency[a.faceId].push([b.faceId, sameDirection]);
      adjacency[b.faceId].push([a.faceId, sameDirection]);
    }
    const flip = new Map(), unsafe = new Set();
    for (let seed=0; seed<kept.length; seed++) {
      if (flip.has(seed) || blocked.has(seed)) continue;
      const queue=[seed], component=[]; flip.set(seed,false); let conflict=false;
      while(queue.length) {
        const current=queue.shift(); component.push(current);
        for (const [next, mustDiffer] of adjacency[current]) {
          if (blocked.has(next)) { conflict=true; continue; }
          const expected=flip.get(current) !== mustDiffer;
          if (!flip.has(next)) { flip.set(next,expected); queue.push(next); }
          else if (flip.get(next)!==expected) conflict=true;
        }
      }
      if (conflict) component.forEach(id=>unsafe.add(id));
    }
    const safeFlips = [...flip].filter(([id,value])=>value && !unsafe.has(id)).map(([id])=>id);
    for (const id of safeFlips) kept[id].reverse();
    this.faces = kept;
    this.compact();
    const after = this.validateTopology();
    return {
      changed: removedInvalidFaces + removedDuplicateFaces + safeFlips.length > 0 || before.details.isolatedVertices.length > 0,
      removedInvalidFaces, removedDuplicateFaces, flippedFaces: safeFlips.length,
      removedIsolatedVertices: before.details.isolatedVertices.length,
      skippedNonManifoldComponents: blocked.size,
      remaining: after
    };
  }

  subdivide() {
    const midpointCache = new Map(), out = [];
    const mid = (a, b) => {
      const key = keyFor(a, b);
      if (midpointCache.has(key)) return midpointCache.get(key);
      const pa = this.positions[a], pb = this.positions[b], id = this.positions.length;
      this.positions.push(pa.map((v, i) => (v + pb[i]) / 2)); midpointCache.set(key, id); return id;
    };
    for (const face of this.faces) {
      if (face.length !== 3) { out.push(face); continue; }
      const [a,b,c] = face, ab = mid(a,b), bc = mid(b,c), ca = mid(c,a);
      out.push([a,ab,ca],[ab,b,bc],[ca,bc,c],[ab,bc,ca]);
    }
    this.faces = out; this.clearSelection(); this.rebuild();
  }

  compact() {
    const used = new Set(this.faces.flat()), ids = new Map(), positions = [];
    for (const old of used) { ids.set(old, positions.length); positions.push(this.positions[old]); }
    this.positions = positions; this.faces = this.faces.map(face => face.map(v => ids.get(v)));
    this.rebuild();
    return ids;
  }
}
