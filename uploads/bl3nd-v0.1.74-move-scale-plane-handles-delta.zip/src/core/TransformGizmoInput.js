const AXES = new Set(['x', 'y', 'z']);

/** Convert SVG data attributes into a safe transform-gizmo action. */
export function resolveTransformGizmoHandle(target) {
  const kind = String(target?.dataset?.gizmoHandle || '');
  if (kind === 'free') return { kind: 'free' };
  if (kind === 'axis') {
    const axis = String(target?.dataset?.axis || '').toLowerCase();
    return AXES.has(axis) ? { kind: 'axis', axis } : null;
  }
  if (kind === 'plane') {
    const plane = String(target?.dataset?.plane || '').toLowerCase();
    const normal = ({ xy: 'z', yz: 'x', xz: 'y' })[plane];
    return normal ? { kind: 'plane', plane, axis: normal } : null;
  }
  return null;
}

/**
 * Keep the full-size SVG overlay transparent to ordinary viewport gestures.
 * Only explicit gizmo handles may receive pointer input.
 */
export function resolveTransformGuidePointerEvents(target) {
  const handle = resolveTransformGizmoHandle(target);
  if (!handle) return 'none';
  return handle.kind === 'axis' ? 'stroke' : 'all';
}

/** Ignore pointer jitter; only a real drag should auto-apply a gizmo transform. */
/** Match a viewport-originated modal drag even if the browser retargets moves. */
export function isTransformPointerOwner(pointerId, event) {
  return Number.isInteger(pointerId) && pointerId >= 0 && Number.isInteger(event?.pointerId) && event.pointerId === pointerId;
}

export function isTransformGizmoDrag(start, current, threshold = 3) {
  const sx = Number(start?.x), sy = Number(start?.y);
  const cx = Number(current?.x), cy = Number(current?.y);
  const limit = Number(threshold);
  if (![sx, sy, cx, cy, limit].every(Number.isFinite) || limit < 0) return false;
  return Math.hypot(cx - sx, cy - sy) >= limit;
}
